// Import necessary packages from Flutter's material library.
import 'package:flutter/material.dart';
// Import the custom converter screen widget.
import 'screens/converter_screen.dart';

// The main function is the starting point for all Flutter apps.
void main() {
  runApp(const UnitConverterApp());
}

// UnitConverterApp is the root widget of the application.
// It's a StatelessWidget because its own properties don't change over time.
class UnitConverterApp extends StatelessWidget {
  const UnitConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // The title of the application, used by the device's task manager.
      title: 'Unit Converter',
      // This removes the debug banner shown in the top-right corner during development.
      debugShowCheckedModeBanner: false,
      // Defines the overall theme of the application.
      theme: ThemeData(
        // Use Material 3 design principles.
        useMaterial3: true,
        // Define a color scheme based on a seed color. Flutter will generate
        // a harmonious color palette from this single color.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.indigo,
          foregroundColor: Colors.white,
        ),
      ),
      // The home property specifies the widget for the default route of the app.
      // DefaultTabController is used to coordinate the TabBar and TabBarView.
      home: DefaultTabController(
        // The number of tabs to be displayed.
        length: 4,
        child: Scaffold(
          // The AppBar at the top of the screen.
          appBar: AppBar(
            title: const Text('Unit Converter'),
            // The bottom part of the AppBar, where we place the TabBar.
            bottom: const TabBar(
              // isScrollable allows tabs to scroll horizontally if they don't fit.
              isScrollable: true,
              // Defines the tabs themselves.
              tabs: [
                Tab(icon: Icon(Icons.straighten), text: 'Length'),
                Tab(icon: Icon(Icons.scale), text: 'Weight'),
                Tab(icon: Icon(Icons.thermostat), text: 'Temperature'),
                Tab(icon: Icon(Icons.aspect_ratio), text: 'Area'),
              ],
            ),
          ),
          // The body of the Scaffold, which displays the content of the selected tab.
          body: const TabBarView(
            // The children of the TabBarView correspond to the tabs in the TabBar.
            children: [
              // Each ConverterScreen is a self-contained unit converter for a specific category.
              // We pass the category name to each screen.
              ConverterScreen(category: 'Length'),
              ConverterScreen(category: 'Weight'),
              ConverterScreen(category: 'Temperature'),
              ConverterScreen(category: 'Area'),
            ],
          ),
        ),
      ),
    );
  }
}
