// A map containing all the conversion data.
// For most units, the value represents the conversion factor relative to a base unit.
// For example, for Length, the base unit is Meter. 1 Kilometer = 1000 Meters.
final Map<String, Map<String, double>> conversionData = {
  'Length': {
    'Meters': 1.0,
    'Kilometers': 1000.0,
    'Miles': 1609.34,
    'Feet': 0.3048,
    'Inches': 0.0254,
    'Yards': 0.9144,
  },
  'Weight': {
    'Grams': 1.0,
    'Kilograms': 1000.0,
    'Pounds': 453.592,
    'Ounces': 28.3495,
    'Tonnes': 1000000.0,
  },
  'Area': {
    'Square Meters': 1.0,
    'Square Kilometers': 1000000.0,
    'Square Miles': 2590000.0,
    'Acres': 4046.86,
    'Hectares': 10000.0,
  },
  // Temperature doesn't use simple factors, so we just list the units.
  // The conversion logic is handled separately.
  'Temperature': {
    'Celsius': 0,
    'Fahrenheit': 0,
    'Kelvin': 0,
  },
};

// A utility class to encapsulate the conversion logic.
class ConverterLogic {
  // A static method that can be called without creating an instance of the class.
  static String convert({
    required String value,
    required String category,
    required String fromUnit,
    required String toUnit,
  }) {
    // If the input is empty, return an empty string.
    if (value.isEmpty) return '';
    
    // Try to parse the input string to a number.
    final double? inputValue = double.tryParse(value);
    if (inputValue == null) return 'Invalid Input';

    // If units are the same, no conversion is needed.
    if (fromUnit == toUnit) return value;

    double result;

    // Handle the special case for Temperature conversion.
    if (category == 'Temperature') {
      result = _convertTemperature(inputValue, fromUnit, toUnit);
    } else {
      // For all other categories, use the factor-based conversion.
      final Map<String, double> units = conversionData[category]!;
      final double fromFactor = units[fromUnit]!;
      final double toFactor = units[toUnit]!;

      // Convert the input value to the base unit, then to the target unit.
      final double valueInBaseUnit = inputValue * fromFactor;
      result = valueInBaseUnit / toFactor;
    }

    // Format the result to a readable string with a fixed number of decimal places.
    return result.toStringAsFixed(4);
  }

  // Private helper method for temperature conversion logic.
  static double _convertTemperature(double value, String from, String to) {
    // First, convert the input temperature to Celsius, which acts as our base unit.
    double valueInCelsius;
    switch (from) {
      case 'Fahrenheit':
        valueInCelsius = (value - 32) * 5 / 9;
        break;
      case 'Kelvin':
        valueInCelsius = value - 273.15;
        break;
      case 'Celsius':
      default:
        valueInCelsius = value;
        break;
    }

    // Then, convert from Celsius to the target unit.
    double result;
    switch (to) {
      case 'Fahrenheit':
        result = (valueInCelsius * 9 / 5) + 32;
        break;
      case 'Kelvin':
        result = valueInCelsius + 273.15;
        break;
      case 'Celsius':
      default:
        result = valueInCelsius;
        break;
    }
    return result;
  }
}
