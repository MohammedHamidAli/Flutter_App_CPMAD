import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// Import the conversion logic and data.
import '../utils/converter_logic.dart';

// A StatefulWidget that creates a user interface for a specific conversion category.
class ConverterScreen extends StatefulWidget {
  final String category;

  // The constructor requires a category to be passed.
  const ConverterScreen({super.key, required this.category});

  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  // Controller to manage the text input field.
  final TextEditingController _inputController = TextEditingController();

  // State variables for the selected units and the result.
  String? _fromUnit;
  String? _toUnit;
  String _result = '';
  List<String> _units = [];

  // This method is called once when the widget is first created.
  @override
  void initState() {
    super.initState();
    // Initialize the list of units based on the widget's category.
    _units = conversionData[widget.category]!.keys.toList();
    // Set the initial 'from' and 'to' units.
    _fromUnit = _units[0];
    _toUnit = _units.length > 1 ? _units[1] : _units[0];

    // Add a listener to the input controller to perform conversion on text change.
    _inputController.addListener(_convert);
  }
  
  // This method is called when the widget is removed from the widget tree.
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed to free up resources.
    _inputController.dispose();
    super.dispose();
  }

  // The core conversion logic method.
  void _convert() {
    // Get the input value from the text field.
    final String inputText = _inputController.text;
    // Use the utility function from converter_logic.dart to perform the calculation.
    final String conversionResult = ConverterLogic.convert(
      value: inputText,
      category: widget.category,
      fromUnit: _fromUnit!,
      toUnit: _toUnit!,
    );

    // Update the UI by calling setState.
    setState(() {
      _result = conversionResult;
    });
  }

  // Swaps the 'from' and 'to' units.
  void _swapUnits() {
    setState(() {
      final String? temp = _fromUnit;
      _fromUnit = _toUnit;
      _toUnit = temp;
      // After swapping, re-run the conversion with the new units.
      _convert();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Use a GestureDetector to dismiss the keyboard when tapping outside the text field.
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: SingleChildScrollView(
        // Padding around the entire screen content.
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Input TextField for the value to be converted.
            TextField(
              controller: _inputController,
              decoration: InputDecoration(
                labelText: 'Enter Value',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              // Specify the keyboard type for numbers (with decimal point).
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              // Allow only numbers and a single decimal point.
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d*')),
              ],
            ),
            const SizedBox(height: 20),

            // Row for the 'From' and 'To' dropdowns and the swap button.
            Row(
              children: [
                // 'From' unit dropdown.
                Expanded(child: _buildUnitDropdown('From', true)),
                // Swap button.
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: IconButton(
                    icon: const Icon(Icons.swap_horiz, color: Colors.indigo),
                    onPressed: _swapUnits,
                    tooltip: 'Swap units',
                  ),
                ),
                // 'To' unit dropdown.
                Expanded(child: _buildUnitDropdown('To', false)),
              ],
            ),
            const SizedBox(height: 30),

            // Display the conversion result.
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.indigo.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  const Text(
                    'Result',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                      color: Colors.indigo,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _result.isEmpty ? '0' : _result,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build a dropdown button for unit selection.
  Widget _buildUnitDropdown(String label, bool isFromUnit) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, color: Colors.black54)),
        const SizedBox(height: 8),
        InputDecorator(
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: isFromUnit ? _fromUnit : _toUnit,
              isExpanded: true,
              items: _units.map((String unit) {
                return DropdownMenuItem<String>(
                  value: unit,
                  child: Text(unit),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  if (isFromUnit) {
                    _fromUnit = newValue;
                  } else {
                    _toUnit = newValue;
                  }
                  // Re-run conversion when a new unit is selected.
                  _convert();
                });
              },
            ),
          ),
        ),
      ],
    );
  }
}
