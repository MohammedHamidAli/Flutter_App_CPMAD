// Import the material package which contains Flutter's Material Design widgets.
import 'package:flutter/material.dart';

// The main function is the entry point for all Flutter apps.
void main() {
  // runApp inflates the given widget and attaches it to the screen.
  runApp(const MyApp());
}

// MyApp is the root widget of the application.
// It's a StatelessWidget because it doesn't hold any mutable state itself.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // The build method describes how to display the widget in terms of other, lower-level widgets.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // The title of the application, used by the operating system.
      title: 'Greeting App',
      // Removes the debug banner from the top-right corner.
      debugShowCheckedModeBanner: false,
      // Sets the default theme for the application.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // The home property sets the default route of the app (the first screen shown).
      home: const GreetingScreen(),
    );
  }
}

// GreetingScreen is a StatefulWidget because its UI needs to change when the user interacts with it.
class GreetingScreen extends StatefulWidget {
  const GreetingScreen({super.key});

  @override
  State<GreetingScreen> createState() => _GreetingScreenState();
}

// This is the private State class for GreetingScreen.
// The underscore (_) at the beginning of the name makes it private to this file.
class _GreetingScreenState extends State<GreetingScreen> {
  // A state variable to hold the greeting message.
  // It's initialized as an empty string.
  String _greetingMessage = '';
  
  // A constant variable for the username.
  final String _username = 'Gemini';

  // This method is called when the button is pressed.
  void _showGreeting() {
    // setState is a crucial Flutter method. It tells the framework that the
    // internal state of this widget has changed, which causes the framework
    // to re-run the build method so the UI can reflect the new state.
    setState(() {
      _greetingMessage = 'Welcome to the world of Flutter! 🚀';
    });
  }

  // The build method for the stateful widget. It's re-run every time setState is called.
  @override
  Widget build(BuildContext context) {
    // Scaffold implements the basic material design visual layout structure.
    return Scaffold(
      // AppBar is the toolbar at the top of the screen.
      appBar: AppBar(
        title: const Text('Greeting App'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      // The body of the scaffold, which contains the primary content.
      // The Center widget centers its child widget.
      body: Center(
        // Column arranges its children widgets in a vertical line.
        child: Column(
          // mainAxisAlignment centers the children vertically within the column.
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // The first Text widget, displaying the initial "Hello" message.
            Text(
              'Hello $_username', // String interpolation to include the username.
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            // A SizedBox provides a fixed-size box for spacing between widgets.
            const SizedBox(height: 20),
            // An ElevatedButton is a Material Design "raised" button.
            ElevatedButton(
              // The onPressed callback is triggered when the button is tapped.
              // It calls our _showGreeting method.
              onPressed: _showGreeting,
              // The child of the button, which is a Text widget displaying the button's label.
              child: const Text('Show Greeting'),
            ),
            const SizedBox(height: 30),
            // The second Text widget, which will display the greeting message.
            // Initially, it displays an empty string. After the button press,
            // it will display the message from the _greetingMessage variable.
            Text(
              _greetingMessage,
              style: const TextStyle(
                fontSize: 20,
                color: Colors.deepPurple,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }
}