package com.example.app18

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
