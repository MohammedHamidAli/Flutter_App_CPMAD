import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() => runApp(const NoteApp());

class NoteApp extends StatelessWidget {
  const NoteApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo, useMaterial3: true),
      home: const NoteScreen(),
    );
  }
}

class NoteScreen extends StatefulWidget {
  const NoteScreen({super.key});
  @override
  State<NoteScreen> createState() => _NoteScreenState();
}

class _NoteScreenState extends State<NoteScreen> {
  int _currentIndex = 0;
  final List<String> _categories = ['Personal', 'Work', 'Ideas'];
  
  // Storage: { 'Personal': ['Note 1', 'Note 2'], 'Work': [...] }
  Map<String, List<String>> _allNotes = {
    'Personal': [],
    'Work': [],
    'Ideas': [],
  };

  @override
  void initState() {
    super.initState();
    _loadNotes();
  }

  // --- Persistent Storage Logic ---

  Future<void> _loadNotes() async {
    final prefs = await SharedPreferences.getInstance();
    final String? encodedData = prefs.getString('notes_data');
    if (encodedData != null) {
      setState(() {
        // Decode JSON string back into a Map
        Map<String, dynamic> decoded = json.decode(encodedData);
        _allNotes = decoded.map((key, value) => MapEntry(key, List<String>.from(value)));
      });
    }
  }

  Future<void> _saveNotes() async {
    final prefs = await SharedPreferences.getInstance();
    // Encode Map into JSON string for storage
    String encodedData = json.encode(_allNotes);
    await prefs.setString('notes_data', encodedData);
  }

  // --- Note Operations ---

  void _addNote() {
    TextEditingController controller = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('New ${_categories[_currentIndex]} Note'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                setState(() {
                  _allNotes[_categories[_currentIndex]]!.add(controller.text);
                });
                _saveNotes();
                Navigator.pop(context);
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _deleteNote(int index) {
    setState(() {
      _allNotes[_categories[_currentIndex]]!.removeAt(index);
    });
    _saveNotes();
  }

  @override
  Widget build(BuildContext context) {
    String currentCat = _categories[_currentIndex];
    List<String> currentNotes = _allNotes[currentCat]!;

    return Scaffold(
      appBar: AppBar(title: Text('$currentCat Notes'), centerTitle: true),
      body: currentNotes.isEmpty
          ? const Center(child: Text('No notes here yet!'))
          : ListView.builder(
              itemCount: currentNotes.length,
              itemBuilder: (context, index) => Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  title: Text(currentNotes[index]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () => _deleteNote(index),
                  ),
                ),
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNote,
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Personal'),
          BottomNavigationBarItem(icon: Icon(Icons.work), label: 'Work'),
          BottomNavigationBarItem(icon: Icon(Icons.lightbulb), label: 'Ideas'),
        ],
      ),
    );
  }
}