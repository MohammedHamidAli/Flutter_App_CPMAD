# Note Taking Flutter Web App

This project is a simple note-taking application built with Flutter for the web. It allows users to create, view, and delete notes categorized into three categories: Personal, Work, and Ideas.

## Features

- Create notes in different categories
- View notes in a list format
- Delete notes as needed
- Persistent storage using Shared Preferences

## Getting Started

To run this project locally, follow these steps:

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/note_taking_flutter_web.git
   cd note_taking_flutter_web
   ```

2. **Install dependencies:**
   Make sure you have Flutter installed on your machine. Then run:
   ```bash
   flutter pub get
   ```

3. **Run the application:**
   You can run the application in a web browser using:
   ```bash
   flutter run -d chrome
   ```

## Deployment

This project is set up to be deployed to GitHub Pages using GitHub Actions. The deployment workflow is defined in the `.github/workflows/deploy.yml` file. 

To deploy the application, push your changes to the `main` branch, and the workflow will automatically build and deploy the app to the `gh-pages` branch.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.