// intro_screen.dart
import 'package:flutter/material.dart';
import 'shared_pref_helper.dart';
import 'dashboard.dart';

class IntroScreen extends StatefulWidget {
  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  final PageController _controller = PageController();
  int _currentPage = 0;

  final List<Map<String, String>> pages = [
    {"image": "assets/intro1.png", "text": "Welcome to our App"},
    {"image": "assets/intro2.png", "text": "Read e-books easily"},
    {"image": "assets/intro3.png", "text": "Track your progress"},
  ];

  void _finishIntro() async {
    await newMethod();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => Dashboard()),
    );
  }

  // 👈 CORRECTION IS HERE: The newMethod must be a simple async function 
  // that calls the correct helper method.
  Future<void> newMethod() async {
    await SharedPrefHelper.setIntroSeen();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView.builder(
        controller: _controller,
        itemCount: pages.length,
        onPageChanged: (index) => setState(() => _currentPage = index),
        itemBuilder: (_, index) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(pages[index]["image"]!),
              SizedBox(height: 20),
              Text(pages[index]["text"]!,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ],
          );
        },
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton(
              child: Text("Skip"),
              onPressed: _finishIntro,
            ),
            ElevatedButton(
              child: Text(_currentPage == pages.length - 1 ? "Finish" : "Next"),
              onPressed: () {
                if (_currentPage == pages.length - 1) {
                  _finishIntro();
                } else {
                  _controller.nextPage(
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeIn,
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}