// shared_pref_helper.dart

import 'package:shared_preferences/shared_preferences.dart'; // <-- 1. ADD THIS IMPORT

class SharedPrefHelper {
  static const String introSeenKey = "intro_seen";
  
  // 2. REMOVE the faulty lines:
  // static get SharedPreferences => null; 
  // static get ( => null; 

  static Future<bool> isIntroSeen() async {
    // Now SharedPreferences is correctly imported and available
    final prefs = await SharedPreferences.getInstance(); 
    return prefs.getBool(introSeenKey) ?? false;
  }

  // 3. Fix the setIntroSeen signature (it doesn't need to take SharedPreferences as an argument)
  static Future<void> setIntroSeen() async { 
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(introSeenKey, true);
  }
}