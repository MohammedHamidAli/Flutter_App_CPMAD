import 'package:flutter/material.dart';

// The main entry point for the Flutter application.
void main() {
  runApp(const ContactDiaryApp());
}

// The root widget of the application.
class ContactDiaryApp extends StatelessWidget {
  const ContactDiaryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Title of the application, shown in the task manager.
      title: 'Contact Diary',
      // The theme for the entire application.
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // The home screen of the app.
      home: const ContactListScreen(),
      // Hides the debug banner in the top-right corner.
      debugShowCheckedModeBanner: false,
    );
  }
}

// A simple data model class to represent a contact.
class Contact {
  final String name;
  final String mobile;
  final String email;

  Contact({required this.name, required this.mobile, required this.email});
}

// The main screen of the app, which is a StatefulWidget to manage the list of contacts.
class ContactListScreen extends StatefulWidget {
  const ContactListScreen({super.key});

  @override
  // Creates the mutable state for this widget.
  State<ContactListScreen> createState() => _ContactListScreenState();
}

// The State class for ContactListScreen, containing the app's logic and UI.
class _ContactListScreenState extends State<ContactListScreen> {
  // A list to hold all the contact objects.
  final List<Contact> _contacts = [];

  // Controllers to manage the text input fields.
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  // A GlobalKey for the form to enable validation.
  final _formKey = GlobalKey<FormState>();

  /// Adds a new contact to the list if the form is valid.
  void _addContact() {
    // Validate the form fields. If they are not empty, proceed.
    if (_formKey.currentState!.validate()) {
      // Create a new Contact object from the text field values.
      final newContact = Contact(
        name: _nameController.text,
        mobile: _mobileController.text,
        email: _emailController.text,
      );

      // Use setState to update the UI by adding the new contact to the list.
      setState(() {
        _contacts.add(newContact);
      });

      // Clear the text fields after adding the contact.
      _nameController.clear();
      _mobileController.clear();
      _emailController.clear();

      // Dismiss the keyboard.
      FocusScope.of(context).unfocus();

      // Show a confirmation message.
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Contact added successfully!'),
          backgroundColor: Colors.teal,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Diary'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Form for adding a new contact.
            _buildContactForm(),
            const SizedBox(height: 20),
            // A divider to separate the form from the list.
            const Divider(),
            // The list of contacts.
            _buildContactList(),
          ],
        ),
      ),
    );
  }

  /// Builds the form widget with text fields and a button.
  Widget _buildContactForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Contact Name',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a name';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _mobileController,
            decoration: const InputDecoration(
              labelText: 'Mobile Number',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.phone),
            ),
            keyboardType: TextInputType.phone,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a mobile number';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _emailController,
            decoration: const InputDecoration(
              labelText: 'Email Address',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.email),
            ),
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter an email';
              }
              if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                return 'Please enter a valid email address';
              }
              return null;
            },
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _addContact,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text(
              'Add Contact',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the list view that displays the contacts.
  Widget _buildContactList() {
    return Expanded(
      child: _contacts.isEmpty
          ? const Center(
              child: Text(
                'No contacts added yet.',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              itemCount: _contacts.length,
              itemBuilder: (context, index) {
                final contact = _contacts[index];
                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.teal,
                      child: Text(
                        contact.name[0].toUpperCase(),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    title: Text(
                      contact.name,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(contact.mobile),
                        Text(contact.email),
                      ],
                    ),
                    isThreeLine: true,
                  ),
                );
              },
            ),
    );
  }

  // Dispose controllers when the widget is removed from the widget tree.
  @override
  void dispose() {
    _nameController.dispose();
    _mobileController.dispose();
    _emailController.dispose();
    super.dispose();
  }
}
