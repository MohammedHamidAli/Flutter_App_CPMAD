import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const GstCalculatorApp());
}

// GstCalculatorApp is the root widget of the application.
class GstCalculatorApp extends StatelessWidget {
  const GstCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // The title of the application.
      title: 'GST Calculator',
      // Hides the debug banner in the top-right corner.
      debugShowCheckedModeBanner: false,
      // Sets the theme for the application.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // The home screen of the application.
      home: const GstCalculatorScreen(),
    );
  }
}

// GstCalculatorScreen is the main screen widget, which is stateful.
class GstCalculatorScreen extends StatefulWidget {
  const GstCalculatorScreen({super.key});

  @override
  State<GstCalculatorScreen> createState() => _GstCalculatorScreenState();
}

class _GstCalculatorScreenState extends State<GstCalculatorScreen> {
  // A boolean to toggle between the two calculation cases.
  // true = Case 1: Calculate from Actual Amount
  // false = Case 2: Calculate from Total Amount
  bool _isCase1 = true;

  // Controllers to manage the text in the input fields.
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _gstController = TextEditingController();

  // Variables to store the calculated results. Initialized to 0.0.
  double _actualAmount = 0.0;
  double _totalAmount = 0.0;
  double _igst = 0.0;
  double _cgst = 0.0;
  double _sgst = 0.0;

  /// Performs the GST calculation based on the selected case.
  void _calculate() {
    // Parse input values from text fields. Default to 0 if parsing fails.
    final double amount = double.tryParse(_amountController.text) ?? 0.0;
    final double gstPercentage = double.tryParse(_gstController.text) ?? 0.0;

    // Ensure GST percentage is a valid number before proceeding.
    if (gstPercentage <= 0) {
      return;
    }
    
    // Use setState to update the UI with the new results.
    setState(() {
      if (_isCase1) {
        // --- CASE 1: Calculate from Actual Amount ---
        final double gstAmount = amount * (gstPercentage / 100);
        
        _actualAmount = amount;
        _totalAmount = amount + gstAmount;
        _igst = gstAmount;
        _cgst = gstAmount / 2;
        _sgst = gstAmount / 2;
      } else {
        // --- CASE 2: Calculate from Total Amount ---
        final double originalAmount = amount / (1 + (gstPercentage / 100));
        final double gstAmount = amount - originalAmount;

        _actualAmount = originalAmount;
        _totalAmount = amount;
        _igst = gstAmount;
        _cgst = gstAmount / 2;
        _sgst = gstAmount / 2;
      }
    });
  }

  /// Resets all input fields and calculated results to their initial state.
  void _reset() {
    setState(() {
      _amountController.clear();
      _gstController.clear();
      _actualAmount = 0.0;
      _totalAmount = 0.0;
      _igst = 0.0;
      _cgst = 0.0;
      _sgst = 0.0;
    });
  }
  
  // Disposing the controllers when the widget is removed from the widget tree
  // to free up resources and prevent memory leaks.
  @override
  void dispose() {
    _amountController.dispose();
    _gstController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('GST Calculator'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SingleChildScrollView(
        // Adds padding around the main content.
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // --- Input Section ---
            _buildInputCard(),
            const SizedBox(height: 20),

            // --- Buttons Section ---
            _buildButtonsRow(),
            const SizedBox(height: 20),

            // --- Output Section ---
            // Only show the results card if a calculation has been made.
            if (_totalAmount > 0) _buildResultsCard(),
          ],
        ),
      ),
    );
  }

  /// Builds the card containing the input fields and the toggle switch.
  Widget _buildInputCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Switch to toggle between Case 1 and Case 2.
            SwitchListTile(
              title: const Text('Calculation Mode'),
              subtitle: Text(
                  _isCase1 ? 'From Actual Amount' : 'From Total Amount'),
              value: _isCase1,
              onChanged: (bool value) {
                setState(() {
                  _isCase1 = value;
                  _reset(); // Reset fields when mode changes for clarity.
                });
              },
            ),
            const SizedBox(height: 16),
            
            // Text field for amount input.
            TextField(
              controller: _amountController,
              decoration: InputDecoration(
                // Label text changes based on the selected case.
                labelText: _isCase1 ? 'Actual Amount' : 'Total Amount',
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.currency_rupee),
              ),
              // Sets the keyboard to show numbers.
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            
            // Text field for GST percentage input.
            TextField(
              controller: _gstController,
              decoration: const InputDecoration(
                labelText: 'GST Percentage (%)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.percent),
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
      ),
    );
  }

  /// Builds the row containing the Calculate and Reset buttons.
  Widget _buildButtonsRow() {
    return Row(
      // Spreads the buttons across the available space.
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Calculate button.
        Expanded(
          child: ElevatedButton.icon(
            icon: const Icon(Icons.calculate),
            label: const Text('Calculate'),
            onPressed: _calculate,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
            ),
          ),
        ),
        const SizedBox(width: 16),
        // Reset button.
        Expanded(
          child: ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text('Reset'),
            onPressed: _reset,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              backgroundColor: Theme.of(context).colorScheme.secondary,
              foregroundColor: Theme.of(context).colorScheme.onSecondary,
            ),
          ),
        ),
      ],
    );
  }

  /// Builds the card that displays the calculation results.
  Widget _buildResultsCard() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Results',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Divider(height: 20),
            // Custom row widget for displaying each result line item.
            _buildResultRow('Actual Amount:', '₹ ${_actualAmount.toStringAsFixed(2)}'),
            _buildResultRow('Total IGST:', '₹ ${_igst.toStringAsFixed(2)}'),
            _buildResultRow('CGST (Central):', '₹ ${_cgst.toStringAsFixed(2)}'),
            _buildResultRow('SGST (State):', '₹ ${_sgst.toStringAsFixed(2)}'),
            const Divider(height: 20),
            // Highlights the final total amount.
            DefaultTextStyle(
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
              child: _buildResultRow(
                'Total Amount:',
                '₹ ${_totalAmount.toStringAsFixed(2)}',
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Helper widget to create a consistent row for displaying results.
  Widget _buildResultRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 16)),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}