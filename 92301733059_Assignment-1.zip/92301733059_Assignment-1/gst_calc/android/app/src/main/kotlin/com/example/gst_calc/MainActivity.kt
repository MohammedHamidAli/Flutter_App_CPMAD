package com.example.gst_calc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
