import 'package:flutter/material.dart';
import 'dart:math';

// --- 1. Data Models ---

// Define available transaction categories
enum Category {
  food,
  salary,
  entertainment,
  transport,
  shopping,
  other,
}

// Define the transaction model
class Transaction {
  final String id;
  final double amount;
  final Category category;
  final String paymentType;
  final DateTime date;
  final bool isExpense; // true for expense, false for income

  Transaction({
    required this.id,
    required this.amount,
    required this.category,
    required this.paymentType,
    required this.date,
    required this.isExpense,
  });
}

// --- 2. State Management (Using InheritedWidget for simplicity without external packages) ---

class ExpenseData extends InheritedWidget {
  final ExpenseController controller;

  const ExpenseData({
    super.key,
    required this.controller,
    required super.child,
  });

  static ExpenseController of(BuildContext context) {
    final ExpenseData? result = context.dependOnInheritedWidgetOfExactType<ExpenseData>();
    assert(result != null, 'No ExpenseData found in context');
    return result!.controller;
  }

  @override
  bool updateShouldNotify(ExpenseData oldWidget) => controller != oldWidget.controller;
}

// Stateful component managing the application data
class ExpenseDataState extends StatefulWidget {
  final Widget child;
  const ExpenseDataState({super.key, required this.child});

  @override
  State<ExpenseDataState> createState() => _ExpenseDataStateState();
}

class _ExpenseDataStateState extends State<ExpenseDataState> {
  // Instance of the controller
  late ExpenseController _controller;

  @override
  void initState() {
    super.initState();
    // Initialize controller and pass the state update function
    _controller = ExpenseController(setStateCallback: _forceUpdate);
  }

  void _forceUpdate() {
    setState(() {}); // Triggers a rebuild of widgets that use ExpenseData.of(context)
  }

  @override
  Widget build(BuildContext context) {
    return ExpenseData(
      controller: _controller,
      child: widget.child,
    );
  }
}

// --- 3. Controller Logic (Holds data and update logic) ---

class ExpenseController {
  final VoidCallback setStateCallback;
  final List<Transaction> transactions = [];

  ExpenseController({required this.setStateCallback}) {
    _addInitialData();
  }

  void _addInitialData() {
    // Income example
    transactions.add(Transaction(
      id: '1',
      amount: 6800.00,
      category: Category.salary,
      paymentType: 'Bank Account',
      date: DateTime(2023, 3, 7),
      isExpense: false,
    ));

    // Expense examples
    transactions.add(Transaction(
      id: '2',
      amount: 12.00,
      category: Category.food,
      paymentType: 'Card',
      date: DateTime.now(),
      isExpense: true,
    ));
    transactions.add(Transaction(
      id: '3',
      amount: 8.00,
      category: Category.entertainment,
      paymentType: 'Card',
      date: DateTime(2023, 3, 7),
      isExpense: true,
    ));
  }

  double get totalIncome => transactions
      .where((t) => !t.isExpense)
      .fold(0.0, (sum, t) => sum + t.amount);

  double get totalSpent => transactions
      .where((t) => t.isExpense)
      .fold(0.0, (sum, t) => sum + t.amount);

  double get netBalance => totalIncome - totalSpent;

  // Function to add a new transaction and notify listeners
  void addTransaction({
    required double amount,
    required Category category,
    required String paymentType,
    required bool isExpense,
  }) {
    final newTransaction = Transaction(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      amount: amount,
      category: category,
      paymentType: paymentType,
      date: DateTime.now(),
      isExpense: isExpense,
    );
    // Add the new transaction
    transactions.add(newTransaction);
    // Notify the UI to rebuild
    setStateCallback();
  }
}

// --- 4. Main App and Routing ---

void main() {
  runApp(const ExpenseApp());
}

class ExpenseApp extends StatelessWidget {
  const ExpenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ExpenseDataState( // Wrap the app with the state provider
      child: MaterialApp(
        title: 'Daily Expense Tracker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.green,
          primaryColor: const Color(0xFF6ABF8C), // Light green from the chart
          scaffoldBackgroundColor: const Color(0xFFF7F9FA), // Off-white background
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFFF7F9FA),
            elevation: 0,
            foregroundColor: Colors.black,
          ),
          fontFamily: 'SF Pro Display', // Reference font from the design
          useMaterial3: true,
        ),
        home: const DashboardView(),
        routes: {
          '/add': (context) => const AddTransactionView(),
        },
      ),
    );
  }
}

// --- 5. Dashboard View (Home Screen) ---

class DashboardView extends StatelessWidget {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = ExpenseData.of(context); // Access controller via InheritedWidget

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              _buildFilterTabs(),
              const SizedBox(height: 20),
              _buildSummaryCard(context, controller), // Pass controller to summary card
              const SizedBox(height: 30),
              _buildRecentTransactionsHeader(),
              const SizedBox(height: 10),
              Expanded(
                child: _buildRecentTransactionsList(controller), // Pass controller to list
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).pushNamed('/add'),
        backgroundColor: Theme.of(context).primaryColor,
        shape: const CircleBorder(),
        child: const Icon(Icons.add, color: Colors.white, size: 30),
      ),
      bottomNavigationBar: _buildBottomNavBar(context),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Hello,', style: TextStyle(fontSize: 20, color: Colors.grey)),
            Text(
              'David',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        IconButton(
          onPressed: () {},
          icon: const Icon(Icons.notifications_none, size: 30),
        ),
      ],
    );
  }

  Widget _buildFilterTabs() {
    return const Row(
      children: [
        _FilterChip(label: 'All', isSelected: true),
        SizedBox(width: 8),
        _FilterChip(label: 'Daily', isSelected: false),
        SizedBox(width: 8),
        _FilterChip(label: 'Weekly', isSelected: false),
        SizedBox(width: 8),
        _FilterChip(label: 'Monthly', isSelected: false),
      ],
    );
  }

  Widget _buildSummaryCard(BuildContext context, ExpenseController controller) {
    // This widget now rebuilds automatically because it accesses the InheritedWidget
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Income',
                style: TextStyle(color: Colors.grey[600], fontSize: 16),
              ),
              Text(
                '\$${controller.totalIncome.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF6ABF8C)),
              ),
              const SizedBox(height: 15),
              Text(
                'Spent',
                style: TextStyle(color: Colors.grey[600], fontSize: 16),
              ),
              Text(
                '\$${controller.totalSpent.toStringAsFixed(2)}',
                style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFEF9088)),
              ),
            ],
          ),
          // Simple visualization mimicking the donut chart
          Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: 100,
                height: 100,
                child: CustomPaint(
                  painter: _DonutChartPainter(
                    income: controller.totalIncome,
                    spent: controller.totalSpent,
                    primaryColor: Theme.of(context).primaryColor,
                  ),
                ),
              ),
              Text(
                '\$${controller.netBalance.toStringAsFixed(0)}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRecentTransactionsHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'Recent transactions',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        TextButton(
          onPressed: () {
            // Placeholder for "See All" functionality
          },
          child: const Text('See All', style: TextStyle(color: Color(0xFF6ABF8C))),
        ),
      ],
    );
  }

  Widget _buildRecentTransactionsList(ExpenseController controller) {
    // This widget now rebuilds automatically because it accesses the InheritedWidget
    return ListView.builder(
      itemCount: controller.transactions.length,
      itemBuilder: (context, index) {
        // Reverse order to show latest transaction first
        final transaction = controller.transactions.reversed.toList()[index];
        return _TransactionItem(transaction: transaction);
      },
    );
  }

  Widget _buildBottomNavBar(BuildContext context) {
    // Minimalistic implementation based on the image
    return BottomAppBar(
      color: Colors.white,
      height: 70,
      shape: const CircularNotchedRectangle(),
      notchMargin: 10.0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          const _NavBarItem(icon: Icons.home, label: 'Home', isSelected: true),
          const _NavBarItem(icon: Icons.compare_arrows, label: 'Transfer'),
          const SizedBox(width: 40), // Spacer for FAB
          const _NavBarItem(icon: Icons.account_balance_wallet, label: 'Wallet'),
          const _NavBarItem(icon: Icons.person_outline, label: 'Profile'),
        ],
      ),
    );
  }
}

// --- 6. Add Transaction View ---

class AddTransactionView extends StatefulWidget {
  const AddTransactionView({super.key});

  @override
  State<AddTransactionView> createState() => _AddTransactionViewState();
}

class _AddTransactionViewState extends State<AddTransactionView> {
  // Controller is retrieved in _submitTransaction to ensure it's available
  final TextEditingController _amountController = TextEditingController();
  Category? _selectedCategory = Category.food;
  String? _selectedPaymentType = 'Cash'; // Default payment type
  bool _isExpense = true; // Default to Expense

  final List<String> _paymentTypes = ['Cash', 'Credit/Debit Card', 'Check'];

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  void _submitTransaction() {
    final amount = double.tryParse(_amountController.text);
    final controller = ExpenseData.of(context); // Get controller instance

    if (amount == null || _selectedCategory == null || _selectedPaymentType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all fields correctly.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    controller.addTransaction(
      amount: amount,
      category: _selectedCategory!,
      paymentType: _selectedPaymentType!,
      isExpense: _isExpense,
    );

    // Show success message and navigate back
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Transaction added!'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Add transaction',
            style: TextStyle(fontWeight: FontWeight.w600)),
        centerTitle: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildAmountField(),
                    const SizedBox(height: 20),
                    _buildCategorySelector(),
                    const SizedBox(height: 20),
                    _buildTransactionTypeToggle(),
                    const SizedBox(height: 20),
                    _buildPaymentTypeSelector(),
                  ],
                ),
              ),
            ),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildTransactionTypeToggle() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Expanded(
            child: _TransactionTypeButton(
              label: 'Expense',
              isSelected: _isExpense,
              onTap: () => setState(() => _isExpense = true),
              color: Colors.redAccent,
            ),
          ),
          Expanded(
            child: _TransactionTypeButton(
              label: 'Income',
              isSelected: !_isExpense,
              onTap: () => setState(() => _isExpense = false),
              color: Colors.green,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAmountField() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Amount',
            style: TextStyle(color: Colors.grey[600]),
          ),
          TextFormField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            decoration: const InputDecoration(
              hintText: '0.00',
              prefixText: '\$',
              prefixStyle: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16),
        leading: Icon(_getCategoryIcon(_selectedCategory!), color: Theme.of(context).primaryColor),
        title: Text(
          'Category',
          style: TextStyle(color: Colors.grey[600], fontSize: 14),
        ),
        trailing: DropdownButtonHideUnderline(
          child: DropdownButton<Category>(
            value: _selectedCategory,
            icon: const Icon(Icons.keyboard_arrow_down),
            items: Category.values.map((Category category) {
              return DropdownMenuItem<Category>(
                value: category,
                child: Text(_getCategoryName(category)),
              );
            }).toList(),
            onChanged: (Category? newValue) {
              setState(() {
                _selectedCategory = newValue;
              });
            },
          ),
        ),
      ),
    );
  }

  Widget _buildPaymentTypeSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Payment Type',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        ..._paymentTypes.map((type) => _PaymentTypeTile(
              label: type,
              isSelected: _selectedPaymentType == type,
              onTap: () => setState(() => _selectedPaymentType = type),
            )),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE0E0E0),
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            ),
            child: const Text('Draft', style: TextStyle(color: Colors.black)),
          ),
        ),
        const SizedBox(width: 15),
        Expanded(
          child: ElevatedButton(
            onPressed: _submitTransaction,
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).primaryColor,
              padding: const EdgeInsets.symmetric(vertical: 18),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            ),
            child: const Text('Add', style: TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }
}

// --- 7. Helper Widgets ---

// Custom painter to draw the simple donut chart based on income vs spent
class _DonutChartPainter extends CustomPainter {
  final double income;
  final double spent;
  final Color primaryColor;

  _DonutChartPainter({required this.income, required this.spent, required this.primaryColor});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = min(size.width / 2, size.height / 2);
    const strokeWidth = 10.0;

    final total = income + spent;
    final spentSweepAngle = (total > 0) ? (spent / total) * 2 * pi : 0;
    final incomeSweepAngle = (total > 0) ? (income / total) * 2 * pi : 2 * pi;

    final spentPaint = Paint()
      ..color = const Color(0xFFEF9088) // Pink/Red from image
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    final incomePaint = Paint()
      ..color = primaryColor // Green from image
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    // Draw the spent arc first
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - strokeWidth / 2),
      -pi / 2, // Start from the top
      spentSweepAngle.toDouble(),
      false,
      spentPaint,
    );

    // Draw the income arc (starting where spent ended)
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - strokeWidth / 2),
      -pi / 2 + spentSweepAngle.toDouble(),
      incomeSweepAngle.toDouble(),
      false,
      incomePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _DonutChartPainter oldDelegate) {
    return oldDelegate.income != income || oldDelegate.spent != spent;
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;

  const _FilterChip({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label),
      backgroundColor: isSelected ? Theme.of(context).primaryColor : Colors.white,
      side: BorderSide.none,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : Colors.black,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    );
  }
}

class _TransactionItem extends StatelessWidget {
  final Transaction transaction;

  const _TransactionItem({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final iconData = _getCategoryIcon(transaction.category);
    final isNegative = transaction.isExpense;
    final amountText = isNegative
        ? '-\$${transaction.amount.toStringAsFixed(2)}'
        : '+\$${transaction.amount.toStringAsFixed(2)}';

    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Row(
          children: [
            // Icon
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(iconData, color: Theme.of(context).primaryColor),
            ),
            const SizedBox(width: 15),
            // Details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getCategoryName(transaction.category),
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    transaction.paymentType,
                    style: TextStyle(color: Colors.grey[600], fontSize: 12),
                  ),
                ],
              ),
            ),
            // Amount and Date
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  amountText,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: isNegative ? const Color(0xFFEF9088) : Theme.of(context).primaryColor,
                  ),
                ),
                Text(
                  '${transaction.date.month.toString().padLeft(2, '0')}/${transaction.date.day.toString().padLeft(2, '0')}, ${transaction.date.year}',
                  style: TextStyle(color: Colors.grey[600], fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _NavBarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;

  const _NavBarItem({required this.icon, required this.label, this.isSelected = false});

  @override
  Widget build(BuildContext context) {
    final color = isSelected ? Theme.of(context).primaryColor : Colors.grey;
    return InkWell(
      onTap: () {
        // Placeholder for navigation logic
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 28),
            Text(label, style: TextStyle(color: color, fontSize: 10)),
          ],
        ),
      ),
    );
  }
}

class _PaymentTypeTile extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _PaymentTypeTile({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? Theme.of(context).primaryColor.withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: isSelected ? Theme.of(context).primaryColor : Colors.grey.withOpacity(0.2),
          ),
        ),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              color: isSelected ? Theme.of(context).primaryColor : Colors.grey,
            ),
            const SizedBox(width: 15),
            Text(label, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class _TransactionTypeButton extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color color;

  const _TransactionTypeButton({
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? color : Colors.black,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}


// Utility function to get icons based on category
IconData _getCategoryIcon(Category category) {
  switch (category) {
    case Category.food:
      return Icons.fastfood_outlined;
    case Category.salary:
      return Icons.attach_money;
    case Category.entertainment:
      return Icons.movie_outlined;
    case Category.transport:
      return Icons.directions_car_filled_outlined;
    case Category.shopping:
      return Icons.shopping_bag_outlined;
    case Category.other:
      return Icons.category_outlined;
  }
}

// Utility function to get human-readable category name
String _getCategoryName(Category category) {
  switch (category) {
    case Category.food:
      return 'Food';
    case Category.salary:
      return 'Salary';
    case Category.entertainment:
      return 'Entertainment';
    case Category.transport:
      return 'Transport';
    case Category.shopping:
      return 'Shopping';
    case Category.other:
      return 'Other';
  }
}