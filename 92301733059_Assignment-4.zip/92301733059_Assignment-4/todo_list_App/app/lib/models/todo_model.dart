import 'package:get/get.dart';

class TodoModel {
  final String title;
  // Use RxBool so that toggling the state updates the UI (the ListTile)
  final RxBool isDone; 

  TodoModel({
    required this.title,
    required RxBool isDone,
  }) : isDone = isDone; 
}