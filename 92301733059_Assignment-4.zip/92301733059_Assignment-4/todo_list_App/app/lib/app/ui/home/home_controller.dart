import 'package:app/models/todo_model.dart';
import 'package:get/get.dart';
import '../../../models/todo_model.dart';
// import 'package:flutter_todo_app/models/todo_model.dart'; // Assume this file exists

class HomeController extends GetxController {
  // Reactive list for todos
  var todos = <TodoModel>[].obs;

  @override
  void onInit() {
    // Load todos from storage if necessary
    super.onInit();
    // Dummy data for demonstration
    todos.add(TodoModel(title: 'Buy Milk', isDone: false.obs));
    todos.add(TodoModel(title: 'Pay Bills', isDone: true.obs));
  }

  void addTodo(String title) {
    if (title.isNotEmpty) {
      todos.add(TodoModel(title: title, isDone: false.obs));
    }
  }

  void toggleDone(TodoModel todo) {
    todo.isDone.toggle(); // Toggles the RxBool inside the model
  }

  void deleteTodo(TodoModel todo) {
    todos.remove(todo);
  }
}