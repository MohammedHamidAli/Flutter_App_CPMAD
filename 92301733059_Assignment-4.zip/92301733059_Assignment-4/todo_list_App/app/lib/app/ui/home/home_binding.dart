import 'package:get/get.dart';
import 'home_controller.dart';

// Initializes HomeController when HomeView is navigated to
class HomeBinding extends Bindings {
  @override
  void dependencies() {
    // LazyPut means the controller is created only when needed, 
    // but kept in memory until the dependency is no longer needed.
    Get.lazyPut<HomeController>(() => HomeController());
  }
}