import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'home_controller.dart';
import '../../routes/app_routes.dart'; // For navigation

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Use '.tr' extension for translation
        title: Text('title'.tr), 
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Get.toNamed(AppRoutes.SETTINGS),
          ),
        ],
      ),
      
      // Obx rebuilds only the widgets inside when a reactive variable changes
      body: Obx(
        () => ListView.builder(
          itemCount: controller.todos.length,
          itemBuilder: (context, index) {
            final todo = controller.todos[index];
            return Obx( // Inner Obx for the reactive bool in the model
              () => ListTile(
                title: Text(
                  todo.title,
                  style: TextStyle(
                    decoration: todo.isDone.value 
                        ? TextDecoration.lineThrough 
                        : TextDecoration.none,
                  ),
                ),
                leading: Checkbox(
                  value: todo.isDone.value,
                  onChanged: (_) => controller.toggleDone(todo),
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => controller.deleteTodo(todo),
                ),
              ),
            );
          },
        ),
      ),
      
      floatingActionButton: FloatingActionButton(
        // Text for FAB is translated
        onPressed: () => _showAddTodoDialog(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  // Simple dialog to add a todo
  void _showAddTodoDialog(BuildContext context) {
    // ... dialog implementation using 'add_todo'.tr for the title
    // ... input field and button that calls controller.addTodo(newTitle)
  }
}