import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SettingsController extends GetxController {
  // Check if the current theme mode is dark
  bool get isDarkMode => Get.isDarkMode;

  // Change Theme (uses Get.changeThemeMode and Get.isDarkMode to save state)
  void changeTheme() {
    Get.changeThemeMode(Get.isDarkMode ? ThemeMode.light : ThemeMode.dark);
    // GetX automatically saves the preference, which is used in GetMaterialApp
  }

  // Change Language/Locale
  void changeLanguage(String langCode, String countryCode) {
    final newLocale = Locale(langCode, countryCode);
    Get.updateLocale(newLocale);
  }
}