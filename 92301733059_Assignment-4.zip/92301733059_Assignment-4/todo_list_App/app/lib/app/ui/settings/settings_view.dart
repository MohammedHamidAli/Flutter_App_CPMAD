import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'settings_controller.dart';

class SettingsView extends GetView<SettingsController> {
  const SettingsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('theme'.tr), // Translated title
      ),
      body: ListView(
        children: [
          // --- Theme Toggle ---
          ListTile(
            leading: Icon(Get.isDarkMode ? Icons.brightness_4 : Icons.brightness_high),
            title: Text('theme'.tr),
            trailing: Switch(
              // GetBuilder is used here to show the current theme state
              value: Get.isDarkMode,
              onChanged: (value) => controller.changeTheme(),
            ),
          ),
          
          const Divider(),

          // --- Language Selection ---
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Text(
              'language'.tr,
              style: context.textTheme.headlineSmall,
            ),
          ),
          
          // English Option
          ListTile(
            title: Text('english'.tr),
            trailing: Get.locale?.languageCode == 'en' ? const Icon(Icons.check) : null,
            onTap: () => controller.changeLanguage('en', 'US'),
          ),
          
          // Arabic Option (RTL language)
          ListTile(
            title: Text('arabic'.tr),
            trailing: Get.locale?.languageCode == 'ar' ? const Icon(Icons.check) : null,
            onTap: () => controller.changeLanguage('ar', 'DZ'),
          ),
        ],
      ),
    );
  }
}