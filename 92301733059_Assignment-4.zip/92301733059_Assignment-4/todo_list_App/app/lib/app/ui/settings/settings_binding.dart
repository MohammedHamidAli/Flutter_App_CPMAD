import 'package:get/get.dart';
import 'settings_controller.dart';

// Initializes SettingsController when SettingsView is navigated to
class SettingsBinding extends Bindings {
  @override
  void dependencies() {
    // FPut/LazyPut can be used here. For simplicity, we use lazy.
    Get.lazyPut<SettingsController>(() => SettingsController());
  }
}