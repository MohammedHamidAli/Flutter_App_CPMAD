// Contains simple string constants for route names
abstract class AppRoutes {
  static const HOME = '/home';
  static const SETTINGS = '/settings';
}