import 'package:get/get.dart';
import '../ui/home/home_view.dart';
import '../ui/home/home_binding.dart';
import '../ui/settings/settings_view.dart';
import '../ui/settings/settings_binding.dart';
import 'app_routes.dart';

class AppPages {
  // A list of all application pages (screens)
  static final routes = [
    GetPage(
      name: AppRoutes.HOME,
      page: () => const HomeView(),
      binding: HomeBinding(), // Links HomeView to HomeController
    ),
    GetPage(
      name: AppRoutes.SETTINGS,
      page: () => const SettingsView(),
      binding: SettingsBinding(), // Links SettingsView to SettingsController
    ),
  ];
}