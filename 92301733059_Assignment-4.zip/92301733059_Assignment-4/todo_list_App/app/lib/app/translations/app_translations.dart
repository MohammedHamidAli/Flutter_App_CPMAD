import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en_US': {
          'title': 'Todo List',
          'add_todo': 'Add New Todo',
          'language': 'Language',
          'theme': 'Theme',
          'light': 'Light',
          'dark': 'Dark',
          'hello_world': 'Hello World',
          'arabic': 'Arabic',
          'english': 'English',
        },
        'ar_DZ': { // Using a common Arabic locale code
          'title': 'قائمة المهام',
          'add_todo': 'إضافة مهمة جديدة',
          'language': 'اللغة',
          'theme': 'السمة',
          'light': 'فاتح',
          'dark': 'داكن',
          'hello_world': 'مرحباً بالعالم',
          'arabic': 'العربية',
          'english': 'الإنجليزية',
        }
      };
}