import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'app/routes/app_pages.dart';
import 'app/routes/app_routes.dart';
import 'app/translations/app_translations.dart';
import 'app/utils/app_themes.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      // 1. THEMES
      theme: AppThemes.lightTheme,
      darkTheme: AppThemes.darkTheme,
      themeMode: ThemeMode.system, // Starts with system preference

      // 2. I18N (Locale/Language)
      translations: AppTranslations(), // The class with all strings
      locale: const Locale('en', 'US'), // Default locale
      fallbackLocale: const Locale('en', 'US'), // Fallback if current locale fails
      
      // GetX automatically sets the text direction (RTL/LTR)
      // based on the current locale! For Arabic, it will be RTL.

      // 3. ROUTING
      initialRoute: AppRoutes.HOME,
      getPages: AppPages.routes,
      
      title: 'Todo List App',
      debugShowCheckedModeBanner: false,
    );
  }
}