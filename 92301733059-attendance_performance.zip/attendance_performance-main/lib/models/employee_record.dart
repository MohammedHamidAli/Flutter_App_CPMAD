import 'package:flutter/material.dart';

/// Represents an employee's attendance record
class EmployeeRecord {
  final int id;
  final String name;
  final AttendanceStatus status;
  final DateTime timestamp;
  final String? department;
  final String? notes;

  const EmployeeRecord({
    required this.id,
    required this.name,
    required this.status,
    required this.timestamp,
    this.department,
    this.notes,
  });

  /// Creates an EmployeeRecord from a formatted string (legacy support)
  static EmployeeRecord fromString(String recordString) {
    // Expected format: "Employee 1 - Present" or similar
    final parts = recordString.split(' - ');
    if (parts.length < 2) {
      return EmployeeRecord(
        id: 0,
        name: recordString,
        status: AttendanceStatus.present,
        timestamp: DateTime.now(),
      );
    }

    final idMatch = RegExp(r'\d+').firstMatch(parts[0]);
    final id = idMatch != null ? int.parse(idMatch.group(0)!) : 0;
    final name = parts[0];
    final status = AttendanceStatus.fromString(parts[1]);

    return EmployeeRecord(
      id: id,
      name: name,
      status: status,
      timestamp: DateTime.now(),
    );
  }

  /// Converts the record to a display string
  String toDisplayString() {
    return 'Employee $id - ${status.displayName}';
  }

  @override
  String toString() {
    return 'EmployeeRecord{id: $id, name: $name, status: $status, timestamp: $timestamp}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is EmployeeRecord &&
        other.id == id &&
        other.name == name &&
        other.status == status;
  }

  @override
  int get hashCode {
    return id.hashCode ^ name.hashCode ^ status.hashCode;
  }
}

/// Represents the attendance status of an employee
enum AttendanceStatus {
  present,
  absent,
  late,
  excused;

  /// Converts string to AttendanceStatus
  static AttendanceStatus fromString(String status) {
    switch (status.toLowerCase()) {
      case 'present':
        return AttendanceStatus.present;
      case 'absent':
        return AttendanceStatus.absent;
      case 'late':
        return AttendanceStatus.late;
      case 'excused':
        return AttendanceStatus.excused;
      default:
        return AttendanceStatus.present;
    }
  }

  /// Returns the display name for the status
  String get displayName {
    switch (this) {
      case AttendanceStatus.present:
        return 'Present';
      case AttendanceStatus.absent:
        return 'Absent';
      case AttendanceStatus.late:
        return 'Late';
      case AttendanceStatus.excused:
        return 'Excused';
    }
  }

  /// Returns the corresponding Material icon
  IconData get icon {
    switch (this) {
      case AttendanceStatus.present:
        return Icons.check_circle;
      case AttendanceStatus.absent:
        return Icons.cancel;
      case AttendanceStatus.late:
        return Icons.access_time;
      case AttendanceStatus.excused:
        return Icons.info;
    }
  }

  /// Returns the color for the status
  Color get color {
    switch (this) {
      case AttendanceStatus.present:
        return Colors.green;
      case AttendanceStatus.absent:
        return Colors.red;
      case AttendanceStatus.late:
        return Colors.orange;
      case AttendanceStatus.excused:
        return Colors.blue;
    }
  }
}