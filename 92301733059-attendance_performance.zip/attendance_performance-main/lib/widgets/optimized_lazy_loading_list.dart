import 'package:flutter/material.dart';
import '../models/employee_record.dart';
import '../core/config.dart';

/// A highly optimized lazy loading list widget for displaying employee records.
/// Implements efficient memory management and smooth scrolling performance.
class OptimizedLazyLoadingList extends StatefulWidget {
  final List<EmployeeRecord> items;
  final Function(EmployeeRecord)? onItemTap;
  final Function()? onLoadMore;
  final bool isLoading;
  final String? emptyMessage;
  final String? errorMessage;
  final AppState state;

  const OptimizedLazyLoadingList({
    super.key,
    required this.items,
    this.onItemTap,
    this.onLoadMore,
    this.isLoading = false,
    this.emptyMessage,
    this.errorMessage,
    this.state = AppState.loaded,
  });

  @override
  State<OptimizedLazyLoadingList> createState() => _OptimizedLazyLoadingListState();
}

class _OptimizedLazyLoadingListState extends State<OptimizedLazyLoadingList> {
  final ScrollController _scrollController = ScrollController();
  final List<EmployeeRecord> _visibleItems = [];
  int _currentIndex = 0;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    _loadInitialBatch();
    _scrollController.addListener(_onScroll);
  }

  @override
  void didUpdateWidget(OptimizedLazyLoadingList oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    // Reset if items changed completely
    if (widget.items != oldWidget.items) {
      _resetList();
    }
  }

  void _resetList() {
    setState(() {
      _visibleItems.clear();
      _currentIndex = 0;
      _isLoadingMore = false;
    });
    _loadInitialBatch();
  }

  void _loadInitialBatch() {
    if (widget.items.isNotEmpty) {
      _loadMore();
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 
        (AppConfig.defaultBatchSize * 10)) {
      _loadMore();
    }
  }

  Future<void> _loadMore() async {
    if (_isLoadingMore || 
        widget.isLoading || 
        _currentIndex >= widget.items.length) {
      return;
    }

    setState(() => _isLoadingMore = true);

    try {
      if (!mounted) return;

      final nextBatch = widget.items.skip(_currentIndex).take(AppConfig.defaultBatchSize).toList();
      
      setState(() {
        _visibleItems.addAll(nextBatch);
        _currentIndex += AppConfig.defaultBatchSize;
        _isLoadingMore = false;
      });

      // Call external load more callback if provided
      widget.onLoadMore?.call();

    } catch (e) {
      setState(() => _isLoadingMore = false);
      if (mounted) {
        _showErrorSnackBar('Failed to load more items: ${e.toString()}');
      }
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Widget _buildStateWidget() {
    switch (widget.state) {
      case AppState.initial:
      case AppState.loading:
        return const _LoadingWidget();
      
      case AppState.processing:
        return const _ProcessingWidget();
      
      case AppState.error:
        return _ErrorWidget(
          message: widget.errorMessage ?? 'An error occurred',
          onRetry: () => _resetList(),
        );
      
      case AppState.empty:
        return _EmptyWidget(
          message: widget.emptyMessage ?? 'No records found',
        );
      
      case AppState.loaded:
        if (widget.items.isEmpty) {
          return _EmptyWidget(
            message: widget.emptyMessage ?? 'No records available',
          );
        }
        return _buildListView();
    }
  }

  Widget _buildListView() {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(AppConfig.smallPadding),
      itemCount: _visibleItems.length + (_isLoadingMore ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == _visibleItems.length) {
          return _isLoadingMore
              ? const _LoadingMoreWidget()
              : const SizedBox.shrink();
        }

        return _EmployeeRecordTile(
          record: _visibleItems[index],
          onTap: widget.onItemTap,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return _buildStateWidget();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
}

// Individual widget classes for better organization

class _LoadingWidget extends StatelessWidget {
  const _LoadingWidget();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: AppConfig.smallPadding),
          Text('Loading employee records...'),
        ],
      ),
    );
  }
}

class _ProcessingWidget extends StatelessWidget {
  const _ProcessingWidget();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: AppConfig.smallPadding),
          Text('Processing data in background...'),
        ],
      ),
    );
  }
}

class _LoadingMoreWidget extends StatelessWidget {
  const _LoadingMoreWidget();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(AppConfig.defaultPadding),
      child: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class _ErrorWidget extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorWidget({
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppConfig.defaultPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: AppConfig.largeIconSize,
              color: Colors.red,
            ),
            const SizedBox(height: AppConfig.smallPadding),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: AppConfig.defaultPadding),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyWidget extends StatelessWidget {
  final String message;

  const _EmptyWidget({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppConfig.defaultPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inbox_outlined,
              size: AppConfig.largeIconSize,
              color: Colors.grey,
            ),
            const SizedBox(height: AppConfig.smallPadding),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmployeeRecordTile extends StatelessWidget {
  final EmployeeRecord record;
  final Function(EmployeeRecord)? onTap;

  const _EmployeeRecordTile({
    required this.record,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(
        vertical: AppConfig.smallPadding / 2,
        horizontal: AppConfig.smallPadding,
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: record.status.color.withValues(alpha: 0.1),
          child: Icon(
            record.status.icon,
            color: record.status.color,
            size: AppConfig.iconSize,
          ),
        ),
        title: Text(
          record.name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ID: ${record.id}'),
            if (record.department != null)
              Text('Department: ${record.department}'),
            Text(
              'Time: ${_formatTime(record.timestamp)}',
              style: const TextStyle(fontSize: AppConfig.smallFontSize),
            ),
          ],
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppConfig.smallPadding,
            vertical: AppConfig.smallPadding / 2,
          ),
          decoration: BoxDecoration(
            color: record.status.color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(AppConfig.borderRadius / 2),
          ),
          child: Text(
            record.status.displayName,
            style: TextStyle(
              color: record.status.color,
              fontWeight: FontWeight.w600,
              fontSize: AppConfig.smallFontSize,
            ),
          ),
        ),
        onTap: () => onTap?.call(record),
      ),
    );
  }

  String _formatTime(DateTime timestamp) {
    return '${timestamp.hour.toString().padLeft(2, '0')}:${timestamp.minute.toString().padLeft(2, '0')}';
  }
}