import 'package:flutter/material.dart';
import '../models/employee_record.dart';
import '../core/config.dart';

/// A comprehensive search and filter widget for employee records
class SearchAndFilterWidget extends StatefulWidget {
  final Function({
    String? searchQuery,
    AttendanceStatus? status,
    String? department,
  }) onFilterChanged;
  final List<String> availableDepartments;
  final bool isLoading;

  const SearchAndFilterWidget({
    super.key,
    required this.onFilterChanged,
    required this.availableDepartments,
    this.isLoading = false,
  });

  @override
  State<SearchAndFilterWidget> createState() => _SearchAndFilterWidgetState();
}

class _SearchAndFilterWidgetState extends State<SearchAndFilterWidget> {
  final TextEditingController _searchController = TextEditingController();
  AttendanceStatus? _selectedStatus;
  String? _selectedDepartment;
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _applyFilters();
  }

  void _applyFilters() {
    widget.onFilterChanged(
      searchQuery: _searchController.text.isNotEmpty ? _searchController.text : null,
      status: _selectedStatus,
      department: _selectedDepartment,
    );
  }

  void _clearAllFilters() {
    setState(() {
      _searchController.clear();
      _selectedStatus = null;
      _selectedDepartment = null;
    });
    widget.onFilterChanged();
    _searchFocusNode.unfocus();
  }

  void _showFilterOptions() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterBottomSheet(
        availableDepartments: widget.availableDepartments,
        selectedStatus: _selectedStatus,
        selectedDepartment: _selectedDepartment,
        onStatusChanged: (status) {
          setState(() => _selectedStatus = status);
          _applyFilters();
        },
        onDepartmentChanged: (department) {
          setState(() => _selectedDepartment = department);
          _applyFilters();
        },
        onClearFilters: _clearAllFilters,
      ),
    );
  }

  bool get _hasActiveFilters {
    return _searchController.text.isNotEmpty ||
           _selectedStatus != null ||
           _selectedDepartment != null;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppConfig.defaultPadding),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search field
          TextField(
            controller: _searchController,
            focusNode: _searchFocusNode,
            decoration: InputDecoration(
              hintText: 'Search employees by name or ID...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        _searchFocusNode.unfocus();
                      },
                    )
                  : null,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppConfig.borderRadius),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: AppConfig.defaultPadding,
                vertical: AppConfig.smallPadding,
              ),
            ),
            enabled: !widget.isLoading,
          ),
          
          const SizedBox(height: AppConfig.smallPadding),
          
          // Filter buttons row
          Row(
            children: [
              // Filter button
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: widget.isLoading ? null : _showFilterOptions,
                  icon: const Icon(Icons.filter_list),
                  label: const Text('Filters'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      vertical: AppConfig.smallPadding,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(width: AppConfig.smallPadding),
              
              // Clear filters button
              if (_hasActiveFilters)
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _clearAllFilters,
                    icon: const Icon(Icons.clear_all),
                    label: const Text('Clear'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        vertical: AppConfig.smallPadding,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          
          // Active filters display
          if (_hasActiveFilters) ...[
            const SizedBox(height: AppConfig.smallPadding),
            _ActiveFiltersDisplay(
              searchQuery: _searchController.text,
              status: _selectedStatus,
              department: _selectedDepartment,
            ),
          ],
        ],
      ),
    );
  }
}

/// Bottom sheet for detailed filter options
class FilterBottomSheet extends StatelessWidget {
  final List<String> availableDepartments;
  final AttendanceStatus? selectedStatus;
  final String? selectedDepartment;
  final Function(AttendanceStatus?) onStatusChanged;
  final Function(String?) onDepartmentChanged;
  final VoidCallback onClearFilters;

  const FilterBottomSheet({
    super.key,
    required this.availableDepartments,
    required this.selectedStatus,
    required this.selectedDepartment,
    required this.onStatusChanged,
    required this.onDepartmentChanged,
    required this.onClearFilters,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.8,
        expand: false,
        builder: (context, scrollController) {
          return SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.all(AppConfig.defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Handle
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: AppConfig.defaultPadding),
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                
                // Title
                const Text(
                  'Filter Options',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                
                const SizedBox(height: AppConfig.defaultPadding),
                
                // Status filter
                Text(
                  'Status',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppConfig.smallPadding),
                Wrap(
                  spacing: AppConfig.smallPadding,
                  runSpacing: AppConfig.smallPadding,
                  children: [
                    _StatusChip(
                      status: null,
                      selected: selectedStatus == null,
                      onTap: () => onStatusChanged(null),
                    ),
                    ...AttendanceStatus.values.map((status) => _StatusChip(
                      status: status,
                      selected: selectedStatus == status,
                      onTap: () => onStatusChanged(status),
                    )),
                  ],
                ),
                
                const SizedBox(height: AppConfig.defaultPadding),
                
                // Department filter
                Text(
                  'Department',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppConfig.smallPadding),
                DropdownButtonFormField<String>(
                  initialValue: selectedDepartment,
                  decoration: const InputDecoration(
                    hintText: 'Select Department',
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem<String>(
                      value: null,
                      child: Text('All Departments'),
                    ),
                    ...availableDepartments.map((dept) => DropdownMenuItem<String>(
                      value: dept,
                      child: Text(dept),
                    )),
                  ],
                  onChanged: onDepartmentChanged,
                ),
                
                const SizedBox(height: AppConfig.largePadding),
                
                // Clear filters button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      onClearFilters();
                      Navigator.of(context).pop();
                    },
                    icon: const Icon(Icons.clear_all),
                    label: const Text('Clear All Filters'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: AppConfig.smallPadding),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Widget for displaying active filters
class _ActiveFiltersDisplay extends StatelessWidget {
  final String searchQuery;
  final AttendanceStatus? status;
  final String? department;

  const _ActiveFiltersDisplay({
    required this.searchQuery,
    required this.status,
    required this.department,
  });

  @override
  Widget build(BuildContext context) {
    final filters = <Widget>[];

    if (searchQuery.isNotEmpty) {
      filters.add(_FilterChip(
        label: 'Search: "$searchQuery"',
        onDeleted: () {},
      ));
    }

    if (status != null) {
      filters.add(_FilterChip(
        label: 'Status: ${status!.displayName}',
        onDeleted: () {},
      ));
    }

    if (department != null) {
      filters.add(_FilterChip(
        label: 'Dept: $department',
        onDeleted: () {},
      ));
    }

    if (filters.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Active Filters:',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: AppConfig.smallPadding),
        Wrap(
          spacing: AppConfig.smallPadding,
          runSpacing: AppConfig.smallPadding,
          children: filters,
        ),
      ],
    );
  }
}

/// Individual status filter chip
class _StatusChip extends StatelessWidget {
  final AttendanceStatus? status;
  final bool selected;
  final VoidCallback onTap;

  const _StatusChip({
    required this.status,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isAll = status == null;
    final label = isAll ? 'All' : status!.displayName;
    final color = isAll ? Colors.grey : status!.color;

    return FilterChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: color.withValues(alpha: 0.2),
      checkmarkColor: color,
      side: BorderSide(
        color: selected ? color : Colors.grey.withValues(alpha: 0.3),
      ),
    );
  }
}

/// Generic filter chip with delete functionality
class _FilterChip extends StatelessWidget {
  final String label;
  final VoidCallback onDeleted;

  const _FilterChip({
    required this.label,
    required this.onDeleted,
  });

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(
        label,
        style: const TextStyle(fontSize: AppConfig.smallFontSize),
      ),
      deleteIcon: const Icon(Icons.close, size: 16),
      onDeleted: onDeleted,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
    );
  }
}