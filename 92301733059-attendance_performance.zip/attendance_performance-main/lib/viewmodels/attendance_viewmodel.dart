import 'package:flutter/material.dart';
import '../models/employee_record.dart';
import '../services/attendance_service.dart';
import '../core/config.dart';

/// View model for managing the attendance screen state
class AttendanceViewModel extends ChangeNotifier {
  // State
  AppState _state = AppState.initial;
  List<EmployeeRecord> _allRecords = [];
  List<EmployeeRecord> _filteredRecords = [];
  String? _errorMessage;
  
  // Search and filter properties
  String? _searchQuery;
  AttendanceStatus? _statusFilter;
  String? _departmentFilter;
  
  // Statistics
  Map<String, int> _statistics = {};

  // Getters
  AppState get state => _state;
  List<EmployeeRecord> get allRecords => _allRecords;
  List<EmployeeRecord> get filteredRecords => _filteredRecords;
  String? get errorMessage => _errorMessage;
  String? get searchQuery => _searchQuery;
  AttendanceStatus? get statusFilter => _statusFilter;
  String? get departmentFilter => _departmentFilter;
  Map<String, int> get statistics => _statistics;
  
  bool get isProcessing => _state == AppState.processing;
  bool get hasError => _state == AppState.error;
  bool get isEmpty => _state == AppState.empty || _filteredRecords.isEmpty;
  bool get isLoaded => _state == AppState.loaded;

  /// Initialize the view model with sample data
  Future<void> initialize() async {
    _updateState(AppState.loading);
    
    try {
      // Generate sample data
      _allRecords = AttendanceService.generateSampleData(AppConfig.defaultListSize);
      _filteredRecords = _allRecords;
      _statistics = AttendanceService.getStatistics(_allRecords);
      
      _updateState(AppState.loaded);
    } catch (e) {
      _errorMessage = 'Failed to initialize data: ${e.toString()}';
      _updateState(AppState.error);
    }
  }

  /// Process records in background using isolates
  Future<void> processRecordsInBackground({String? filterCriteria}) async {
    if (_allRecords.isEmpty) {
      await initialize();
    }
    
    _updateState(AppState.processing);
    
    try {
      final result = await AttendanceService.processInBackground(
        _allRecords,
        filterCriteria: filterCriteria,
      );
      
      if (result.isSuccess) {
        _filteredRecords = result.data ?? [];
        _updateState(AppState.loaded);
      } else {
        _errorMessage = result.error ?? 'Unknown processing error';
        _updateState(AppState.error);
      }
    } catch (e) {
      _errorMessage = 'Background processing failed: ${e.toString()}';
      _updateState(AppState.error);
    }
  }

  /// Apply search and filter criteria
  void applyFilters({
    String? searchQuery,
    AttendanceStatus? status,
    String? department,
  }) {
    _searchQuery = searchQuery;
    _statusFilter = status;
    _departmentFilter = department;
    
    if (_allRecords.isEmpty) return;
    
    _updateState(AppState.loading);
    
    try {
      _filteredRecords = AttendanceService.filterRecords(
        _allRecords,
        searchQuery: searchQuery,
        status: status,
        department: department,
      );
      
      // Recalculate statistics for filtered results
      _statistics = AttendanceService.getStatistics(_filteredRecords);
      
      _updateState(AppState.loaded);
    } catch (e) {
      _errorMessage = 'Failed to apply filters: ${e.toString()}';
      _updateState(AppState.error);
    }
  }

  /// Clear all filters
  void clearFilters() {
    _searchQuery = null;
    _statusFilter = null;
    _departmentFilter = null;
    
    _filteredRecords = _allRecords;
    _statistics = AttendanceService.getStatistics(_allRecords);
    
    notifyListeners();
  }

  /// Handle user interaction with an employee record
  void onEmployeeRecordTap(EmployeeRecord record) {
    // Show details or navigate to record details screen
    // This is a placeholder for actual implementation
    debugPrint('Tapped on employee record: ${record.id}');
  }

  /// Refresh data
  Future<void> refresh() async {
    await initialize();
  }

  /// Get unique departments for filter dropdown
  List<String> get availableDepartments {
    final departments = <String>{};
    for (final record in _allRecords) {
      if (record.department != null) {
        departments.add(record.department!);
      }
    }
    return departments.toList()..sort();
  }

  /// Update the state and notify listeners
  void _updateState(AppState newState) {
    _state = newState;
    notifyListeners();
  }

  /// Get display-friendly state message
  String getStateMessage() {
    switch (_state) {
      case AppState.initial:
        return 'Initializing...';
      case AppState.loading:
        return 'Loading records...';
      case AppState.loaded:
        return _filteredRecords.isEmpty ? 'No records found' : '';
      case AppState.processing:
        return 'Processing data in background...';
      case AppState.error:
        return _errorMessage ?? 'An error occurred';
      case AppState.empty:
        return 'No records available';
    }
  }

  /// Get statistics display text
  String getStatisticsText() {
    if (_statistics.isEmpty) return '';
    
    final total = _filteredRecords.length;
    final parts = <String>[];
    
    for (final entry in _statistics.entries) {
      parts.add('${entry.key}: ${entry.value}');
    }
    
    return 'Total: $total (${parts.join(', ')})';
  }

  void disposeResources() {
    super.dispose();
  }
}