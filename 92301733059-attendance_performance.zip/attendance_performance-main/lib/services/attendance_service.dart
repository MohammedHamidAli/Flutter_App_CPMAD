import 'dart:isolate';
import '../models/employee_record.dart';
import '../core/config.dart';

/// Service responsible for processing attendance data
class AttendanceService {
  /// Processes employee records in background using isolates
  static Future<ProcessingResult<List<EmployeeRecord>>> processInBackground(
    List<EmployeeRecord> records, {
    String? filterCriteria,
  }) async {
    try {
      // Create a receive port to receive messages from the isolate
      final receivePort = ReceivePort();

      // Spawn isolate and send the SendPort to it
      await Isolate.spawn(_processRecords, receivePort.sendPort);

      // Get the isolate's SendPort (first message)
      final sendPort = await receivePort.first as SendPort;

      // Create another port for receiving processed data
      final responsePort = ReceivePort();

      // Send [records, filterCriteria, responsePort.sendPort] to the isolate
      sendPort.send([
        records,
        filterCriteria,
        responsePort.sendPort,
      ]);

      // Wait for the isolate to send back processed data
      final result = await responsePort.first as ProcessingResult<List<EmployeeRecord>>;

      // Close ports to prevent memory leaks
      receivePort.close();
      responsePort.close();

      return result;
    } catch (e) {
      return ProcessingResult.failure(
        'Failed to process records: ${e.toString()}',
        ErrorType.system,
      );
    }
  }

  /// Generates sample employee data for demonstration
  static List<EmployeeRecord> generateSampleData(int count) {
    final statuses = AttendanceStatus.values;
    final departments = ['Engineering', 'HR', 'Sales', 'Marketing', 'Finance'];
    final random = DateTime.now().millisecondsSinceEpoch % 1000;

    return List.generate(count, (index) {
      final status = statuses[index % statuses.length];
      final department = departments[index % departments.length];
      final employeeId = (random + index) % 10000;

      return EmployeeRecord(
        id: employeeId,
        name: 'Employee $employeeId',
        status: status,
        timestamp: DateTime.now().subtract(Duration(hours: index % 24)),
        department: department,
        notes: status == AttendanceStatus.late 
            ? 'Traffic delay' 
            : status == AttendanceStatus.absent 
                ? 'Sick leave' 
                : null,
      );
    });
  }

  /// Filters employee records based on criteria
  static List<EmployeeRecord> filterRecords(
    List<EmployeeRecord> records, {
    String? searchQuery,
    AttendanceStatus? status,
    String? department,
  }) {
    var filtered = records;

    // Filter by search query
    if (searchQuery != null && searchQuery.isNotEmpty) {
      filtered = filtered.where((record) {
        return record.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
               record.id.toString().contains(searchQuery);
      }).toList();
    }

    // Filter by status
    if (status != null) {
      filtered = filtered.where((record) => record.status == status).toList();
    }

    // Filter by department
    if (department != null && department.isNotEmpty) {
      filtered = filtered.where((record) {
        return record.department?.toLowerCase() == department.toLowerCase();
      }).toList();
    }

    return filtered;
  }

  /// Gets statistics from employee records
  static Map<String, int> getStatistics(List<EmployeeRecord> records) {
    final stats = <String, int>{};
    
    for (final record in records) {
      final statusKey = record.status.displayName;
      stats[statusKey] = (stats[statusKey] ?? 0) + 1;
    }
    
    return stats;
  }

  /// Static method to be run in isolate for heavy processing
  static void _processRecords(SendPort mainSendPort) {
    // Create a port to receive data from main isolate
    final port = ReceivePort();

    // Send this port's sendPort to main isolate
    mainSendPort.send(port.sendPort);

    // Listen for messages (data + filter criteria + replyPort)
    port.listen((message) {
      try {
        final records = message[0] as List<EmployeeRecord>;
        final filterCriteria = message[1] as String?;
        final replyPort = message[2] as SendPort;

        // Simulate heavy processing with filtering
        List<EmployeeRecord> processed;

        if (filterCriteria != null && filterCriteria.isNotEmpty) {
          // Apply filtering based on criteria
          processed = records.where((record) {
            return record.name.toLowerCase().contains(filterCriteria.toLowerCase()) ||
                   record.id.toString().contains(filterCriteria) ||
                   record.status.displayName.toLowerCase().contains(filterCriteria.toLowerCase());
          }).toList();
        } else {
          // Default filtering - show only present employees
          processed = records.where((record) {
            return record.status == AttendanceStatus.present;
          }).toList();
        }

        // Simulate processing delay
        // In real application, this would be actual data processing
        Future.delayed(AppConfig.mediumAnimation).then((_) {
          // Send the result back
          replyPort.send(ProcessingResult.success(processed));
        });

      } catch (e) {
        final replyPort = message[2] as SendPort;
        replyPort.send(ProcessingResult.failure(
          'Processing error: ${e.toString()}',
          ErrorType.system,
        ));
      }
    });
  }
}