/// App configuration and constants
class AppConfig {
  // App Information
  static const String appName = 'Attendance Performance Demo';
  static const String appVersion = '2.0.0';

  // Performance Settings
  static const int defaultBatchSize = 20;
  static const int defaultListSize = 1000;
  static const int filterDelayMilliseconds = 500;

  // Lazy Loading Settings
  static const int lazyLoadThreshold = 3; // Load more when 3 items from bottom
  
  // Database/Storage Settings
  static const String defaultDatabaseName = 'attendance.db';
  static const int databaseVersion = 1;

  // Theme Settings
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
  static const double borderRadius = 12.0;

  // Animation Settings
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 400);
  static const Duration longAnimation = Duration(milliseconds: 800);

  // API Settings
  static const Duration requestTimeout = Duration(seconds: 30);
  static const int maxRetries = 3;

  // Filter Settings
  static const List<String> defaultFilterKeywords = [
    'present',
    'absent', 
    'late',
    'excused',
  ];

  // Icon Settings
  static const double iconSize = 24.0;
  static const double smallIconSize = 16.0;
  static const double largeIconSize = 32.0;

  // Text Settings
  static const double defaultFontSize = 14.0;
  static const double smallFontSize = 12.0;
  static const double largeFontSize = 18.0;
}

/// Application states
enum AppState {
  initial,
  loading,
  loaded,
  processing,
  error,
  empty;

  bool get isLoading => this == AppState.loading || this == AppState.processing;
  bool get isError => this == AppState.error;
  bool get isEmpty => this == AppState.empty;
}

/// Error types for better error handling
enum ErrorType {
  network,
  data,
  validation,
  system,
  unknown;
}

/// Processing result for business operations
class ProcessingResult<T> {
  final bool success;
  final T? data;
  final String? error;
  final ErrorType? errorType;

  const ProcessingResult({
    required this.success,
    this.data,
    this.error,
    this.errorType,
  });

  /// Create a successful result
  factory ProcessingResult.success(T data) {
    return ProcessingResult(
      success: true,
      data: data,
    );
  }

  /// Create a failure result
  factory ProcessingResult.failure(String error, [ErrorType errorType = ErrorType.unknown]) {
    return ProcessingResult(
      success: false,
      error: error,
      errorType: errorType,
    );
  }

  /// Check if result is successful
  bool get isSuccess => success;

  /// Check if result failed
  bool get isFailure => !success;
}