import '../services/attendance_service.dart';
import '../viewmodels/attendance_viewmodel.dart';

/// Simple dependency injection container for the application
class AppContainer {
  static final AppContainer _instance = AppContainer._internal();
  factory AppContainer() => _instance;
  AppContainer._internal();

  // Services
  static AttendanceService? _attendanceService;
  
  // ViewModels
  static AttendanceViewModel? _attendanceViewModel;

  /// Get or create the AttendanceService instance
  static AttendanceService get attendanceService {
    _attendanceService ??= AttendanceService();
    return _attendanceService!;
  }

  /// Get or create the AttendanceViewModel instance
  static AttendanceViewModel get attendanceViewModel {
    _attendanceViewModel ??= AttendanceViewModel();
    return _attendanceViewModel!;
  }

  /// Reset all instances (useful for testing)
  static void reset() {
    _attendanceService = null;
    _attendanceViewModel = null;
  }

  /// Dispose all instances
  static void dispose() {
    _attendanceViewModel?.disposeResources();
    _attendanceViewModel = null;
    _attendanceService = null;
  }
}