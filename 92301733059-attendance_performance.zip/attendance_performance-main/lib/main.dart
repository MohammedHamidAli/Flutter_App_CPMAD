import 'package:flutter/material.dart';
import 'core/config.dart';
import 'core/container.dart';
import 'viewmodels/attendance_viewmodel.dart';
import 'widgets/optimized_lazy_loading_list.dart';
import 'widgets/search_and_filter_widget.dart';

void main() {
  runApp(const RefactoredAttendanceApp());
}

class RefactoredAttendanceApp extends StatelessWidget {
  const RefactoredAttendanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConfig.appName,
      theme: ThemeData(
        colorSchemeSeed: Colors.blue,
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
      ),
      home: const RefactoredAttendanceHome(),
    );
  }
}

class RefactoredAttendanceHome extends StatefulWidget {
  const RefactoredAttendanceHome({super.key});

  @override
  State<RefactoredAttendanceHome> createState() => _RefactoredAttendanceHomeState();
}

class _RefactoredAttendanceHomeState extends State<RefactoredAttendanceHome> {
  late final AttendanceViewModel _viewModel;

  @override
  void initState() {
    super.initState();
    _viewModel = AppContainer.attendanceViewModel;
    _viewModel.initialize();
  }

  @override
  void dispose() {
    AppContainer.dispose();
    super.dispose();
  }

  Future<void> _runIsolateProcessing() async {
    await _viewModel.processRecordsInBackground();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Performance Demo'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _viewModel.isProcessing ? null : () => _viewModel.refresh(),
            tooltip: 'Refresh data',
          ),
          IconButton(
            icon: const Icon(Icons.analytics),
            onPressed: _viewModel.isEmpty ? null : _showStatistics,
            tooltip: 'Show statistics',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search and filter widget
          SearchAndFilterWidget(
            onFilterChanged: _viewModel.applyFilters,
            availableDepartments: _viewModel.availableDepartments,
            isLoading: _viewModel.isProcessing,
          ),
          
          // Statistics bar
          if (_viewModel.isLoaded && !_viewModel.isEmpty)
            _StatisticsBar(
              statistics: _viewModel.statistics,
              totalRecords: _viewModel.filteredRecords.length,
            ),
          
          // Main content
          Expanded(
            child: AnimatedBuilder(
              animation: _viewModel,
              builder: (context, child) {
                return OptimizedLazyLoadingList(
                  items: _viewModel.filteredRecords,
                  onItemTap: _viewModel.onEmployeeRecordTap,
                  isLoading: _viewModel.isProcessing,
                  state: _viewModel.state,
                  errorMessage: _viewModel.errorMessage,
                );
              },
            ),
          ),
          
          // Processing indicator
          if (_viewModel.isProcessing)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(AppConfig.smallPadding),
              color: Theme.of(context).colorScheme.surface,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  const SizedBox(width: AppConfig.smallPadding),
                  Text(_viewModel.getStateMessage()),
                  const SizedBox(width: AppConfig.smallPadding),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Cancel operation if needed
                    },
                    icon: const Icon(Icons.cancel, size: 16),
                    label: const Text('Cancel'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppConfig.smallPadding,
                        vertical: 4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _viewModel.isProcessing ? null : _runIsolateProcessing,
        icon: const Icon(Icons.memory),
        label: const Text('Process Background'),
        tooltip: 'Process data using isolates for better performance',
      ),
    );
  }

  void _showStatistics() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => _StatisticsBottomSheet(
        statistics: _viewModel.statistics,
        totalRecords: _viewModel.filteredRecords.length,
      ),
    );
  }
}

/// Statistics display bar
class _StatisticsBar extends StatelessWidget {
  final Map<String, int> statistics;
  final int totalRecords;

  const _StatisticsBar({
    required this.statistics,
    required this.totalRecords,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConfig.defaultPadding,
        vertical: AppConfig.smallPadding,
      ),
      color: Theme.of(context).colorScheme.surfaceContainer,
      child: Row(
        children: [
          Icon(
            Icons.people,
            size: AppConfig.iconSize,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: AppConfig.smallPadding),
          Text(
            'Total: $totalRecords records',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const Spacer(),
          Expanded(
            child: Wrap(
              alignment: WrapAlignment.end,
              spacing: AppConfig.smallPadding,
              children: [
                ...statistics.entries.take(2).map((entry) => _StatChip(
                  label: entry.key,
                  count: entry.value,
                  color: _getStatusColor(entry.key, context),
                )),
                if (statistics.length > 2)
                  Text(
                    '+${statistics.length - 2}',
                    style: TextStyle(
                      fontSize: AppConfig.smallFontSize,
                      color: Colors.grey,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status, BuildContext context) {
    switch (status.toLowerCase()) {
      case 'present':
        return Colors.green;
      case 'absent':
        return Colors.red;
      case 'late':
        return Colors.orange;
      case 'excused':
        return Colors.blue;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }
}

/// Individual statistics chip
class _StatChip extends StatelessWidget {
  final String label;
  final int count;
  final Color color;

  const _StatChip({
    required this.label,
    required this.count,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppConfig.smallPadding,
        vertical: 2,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppConfig.borderRadius / 2),
      ),
      child: Text(
        '$label: $count',
        style: TextStyle(
          color: color,
          fontSize: AppConfig.smallFontSize,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

/// Detailed statistics bottom sheet
class _StatisticsBottomSheet extends StatelessWidget {
  final Map<String, int> statistics;
  final int totalRecords;

  const _StatisticsBottomSheet({
    required this.statistics,
    required this.totalRecords,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.3,
        maxChildSize: 0.8,
        expand: false,
        builder: (context, scrollController) {
          return SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.all(AppConfig.defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Handle
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    margin: const EdgeInsets.only(bottom: AppConfig.defaultPadding),
                    decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                
                // Title
                Row(
                  children: [
                    Icon(
                      Icons.analytics,
                      size: AppConfig.largeIconSize,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: AppConfig.smallPadding),
                    const Text(
                      'Attendance Statistics',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: AppConfig.defaultPadding),
                
                // Total
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(AppConfig.defaultPadding),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Total Records',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(
                          totalRecords.toString(),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: AppConfig.smallPadding),
                
                // Status breakdown
                Text(
                  'Status Breakdown',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppConfig.smallPadding),
                
                ...statistics.entries.map((entry) => Card(
                  margin: const EdgeInsets.only(bottom: AppConfig.smallPadding),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: _getStatusColor(entry.key, context).withValues(alpha: 0.1),
                      child: Icon(
                        _getStatusIcon(entry.key),
                        color: _getStatusColor(entry.key, context),
                        size: AppConfig.iconSize,
                      ),
                    ),
                    title: Text(entry.key),
                    trailing: Text(
                      '${entry.value} (${(entry.value / totalRecords * 100).toStringAsFixed(1)}%)',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                )),
              ],
            ),
          );
        },
      ),
    );
  }

  Color _getStatusColor(String status, BuildContext context) {
    switch (status.toLowerCase()) {
      case 'present':
        return Colors.green;
      case 'absent':
        return Colors.red;
      case 'late':
        return Colors.orange;
      case 'excused':
        return Colors.blue;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'present':
        return Icons.check_circle;
      case 'absent':
        return Icons.cancel;
      case 'late':
        return Icons.access_time;
      case 'excused':
        return Icons.info;
      default:
        return Icons.person;
    }
  }
}
