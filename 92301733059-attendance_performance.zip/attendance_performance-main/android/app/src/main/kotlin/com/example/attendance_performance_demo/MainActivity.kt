package com.example.attendance_performance_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
