// This is a basic Flutter widget test for the refactored attendance demo app.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:attendance_performance_demo/main.dart';

void main() {
  testWidgets('Attendance app loads correctly', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const RefactoredAttendanceApp());

    // Verify that our app title is shown.
    expect(find.text('Attendance Performance Demo'), findsOneWidget);
    
    // Verify that search field is present
    expect(find.byType(TextField), findsOneWidget);
    
    // Verify that filter buttons are present
    expect(find.text('Filters'), findsOneWidget);
  });

  testWidgets('Filter functionality works', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const RefactoredAttendanceApp());
    
    // Wait for the app to initialize
    await tester.pumpAndSettle();
    
    // Find and tap the filter button
    await tester.tap(find.text('Filters'));
    await tester.pumpAndSettle();
    
    // Verify that filter options are shown
    expect(find.text('Filter Options'), findsOneWidget);
    expect(find.text('Status'), findsOneWidget);
    expect(find.text('Department'), findsOneWidget);
  });
}
