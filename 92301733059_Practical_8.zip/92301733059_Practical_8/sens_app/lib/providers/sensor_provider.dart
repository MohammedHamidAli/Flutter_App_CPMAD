import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../services/sensor_service.dart';

class SensorProvider extends ChangeNotifier {
  final SensorService _service = SensorService();

  // Latest values
  double x = 0, y = 0, z = 0;

  // Derived metrics
  double magnitude = 0;
  double avgMagnitude = 0;

  // Series for chart (most recent first or last? We store last as newest)
  final List<double> _magnitudeSeries = <double>[];
  final List<double> _movingAvgSeries = <double>[];

  // Controls
  int window = 10;
  int maxPoints = 300;
  double threshold = 12.0;

  // State
  bool supported = true;
  bool isListening = false;

  List<double> get magnitudeSeries => List.unmodifiable(_magnitudeSeries);
  List<double> get movingAvgSeries => List.unmodifiable(_movingAvgSeries);

  bool get isAnomaly => magnitude >= threshold;

  void init() {
    // Some devices may lack sensors; try-catch for resilience.
    try {
      start();
    } catch (_) {
      supported = false;
      notifyListeners();
    }
  }

  void start() {
    if (isListening) return;
    _service.start(_onAccel);
    isListening = true;
    notifyListeners();
  }

  Future<void> stop() async {
    if (!isListening) return;
    await _service.stop();
    isListening = false;
    notifyListeners();
  }

  void toggleListening() {
    isListening ? stop() : start();
  }

  void _onAccel(AccelerometerEvent e) {
    x = e.x;
    y = e.y;
    z = e.z;
    magnitude = _norm3(x, y, z);

    _appendPoint(magnitude);

    avgMagnitude = _movingAverage(_magnitudeSeries, window);
    _movingAvgSeries.add(avgMagnitude);
    _trimSeries();

    // Trigger UI update
    notifyListeners();
  }

  void _appendPoint(double v) {
    _magnitudeSeries.add(v);
    if (_magnitudeSeries.length > maxPoints) {
      _magnitudeSeries.removeAt(0);
    }
  }

  void _trimSeries() {
    while (_movingAvgSeries.length > maxPoints) {
      _movingAvgSeries.removeAt(0);
    }
  }

  void setWindow(int w) {
    window = w.clamp(3, 500);
    // Recompute MA series from scratch for consistency
    _recomputeMA();
    notifyListeners();
  }

  void setMaxPoints(int m) {
    maxPoints = m.clamp(50, 2000);
    while (_magnitudeSeries.length > maxPoints) {
      _magnitudeSeries.removeAt(0);
    }
    while (_movingAvgSeries.length > maxPoints) {
      _movingAvgSeries.removeAt(0);
    }
    notifyListeners();
  }

  void setThreshold(double t) {
    threshold = t.clamp(0.5, 100.0);
    notifyListeners();
  }

  void clearHistory() {
    _magnitudeSeries.clear();
    _movingAvgSeries.clear();
    avgMagnitude = 0;
    notifyListeners();
  }

  double _norm3(double x, double y, double z) {
    return math.sqrt(x * x + y * y + z * z);
  }

  /// Latest window moving average in O(n) per sample; recompute helper below for full series.
  double _movingAverage(List<double> s, int w) {
    if (s.isEmpty) return 0;
    final len = s.length;
    int start = len - w;
    if (start < 0) start = 0;
    double sum = 0;
    for (int i = start; i < len; i++) {
      sum += s[i];
    }
    return sum / (len - start);
  }

  void _recomputeMA() {
    _movingAvgSeries.clear();
    double sum = 0;
    final q = <double>[];
    for (final v in _magnitudeSeries) {
      q.add(v);
      sum += v;
      if (q.length > window) {
        sum -= q.first;
        q.removeAt(0);
      }
      _movingAvgSeries.add(sum / q.length);
    }
  }
}
