import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/sensor_provider.dart';
import 'widgets/value_tile.dart';
import 'widgets/line_chart.dart';

void main() {
  runApp(const SensorAnalyzerApp());
}

class SensorAnalyzerApp extends StatelessWidget {
  const SensorAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SensorProvider()..init()),
      ],
      child: MaterialApp(
        title: 'Sensor Analyzer',
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF1565C0),
          brightness: Brightness.light,
          useMaterial3: true,
        ),
        home: const SensorHomePage(),
      ),
    );
  }
}

class SensorHomePage extends StatelessWidget {
  const SensorHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final sensor = context.watch<SensorProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Sensor Analyzer'),
        actions: [
          IconButton(
            tooltip: sensor.isListening ? 'Pause' : 'Resume',
            onPressed: () => sensor.toggleListening(),
            icon: Icon(sensor.isListening ? Icons.pause_circle : Icons.play_circle),
          ),
          IconButton(
            tooltip: 'Clear history',
            onPressed: sensor.clearHistory,
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: sensor.supported
            ? Padding(
                padding: const EdgeInsets.all(16),
                child: ListView(
                  children: [
                    const Text(
                      'Accelerometer (m/s²)',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        ValueTile(label: 'X', value: sensor.x),
                        ValueTile(label: 'Y', value: sensor.y),
                        ValueTile(label: 'Z', value: sensor.z),
                        ValueTile(label: 'Magnitude', value: sensor.magnitude),
                        ValueTile(label: 'Avg Mag (MA)',
                            value: sensor.avgMagnitude, subtitle: 'window=${sensor.window}'),
                      ],
                    ),
                    const SizedBox(height: 16),
                    LineChartWidget(
                      title: 'Magnitude over time',
                      series: [
                        ('Raw', sensor.magnitudeSeries, Colors.blue),
                        ('MA', sensor.movingAvgSeries, Colors.orange),
                      ],
                      maxPoints: sensor.maxPoints,
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: Slider(
                            label: 'Window: ${sensor.window}',
                            value: sensor.window.toDouble(),
                            min: 3,
                            max: 50,
                            divisions: 47,
                            onChanged: (v) => sensor.setWindow(v.round()),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text('Window: ${sensor.window}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Slider(
                            label: 'Max points: ${sensor.maxPoints}',
                            value: sensor.maxPoints.toDouble(),
                            min: 100,
                            max: 1000,
                            divisions: 9,
                            onChanged: (v) => sensor.setMaxPoints(v.round()),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text('Max: ${sensor.maxPoints}'),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Card(
                      elevation: 0.5,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Anomaly detection (threshold on magnitude)',
                                style: TextStyle(fontWeight: FontWeight.w600)),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: Slider(
                                    label: 'Threshold: ${sensor.threshold.toStringAsFixed(1)}',
                                    value: sensor.threshold,
                                    min: 2,
                                    max: 25,
                                    divisions: 46,
                                    onChanged: sensor.setThreshold,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(sensor.isAnomaly
                                    ? 'Status: Anomaly'
                                    : 'Status: Normal',
                                    style: TextStyle(
                                      color: sensor.isAnomaly ? Colors.red : Colors.green,
                                      fontWeight: FontWeight.w600,
                                    )),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )
            : const Center(
                child: Text(
                  'Accelerometer not available on this device.',
                  textAlign: TextAlign.center,
                ),
              ),
      ),
    );
  }
}
