import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

typedef SeriesDef = (String name, List<double> data, Color color);

class LineChartWidget extends StatelessWidget {
  final String title;
  final List<SeriesDef> series;
  final int maxPoints;

  const LineChartWidget({
    super.key,
    required this.title,
    required this.series,
    required this.maxPoints,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final length = series.isNotEmpty ? series.first.$2.length : 0;
    final maxY = _maxY(series);
    final minY = _minY(series);

    return Card(
      elevation: 0.5,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title, style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            SizedBox(
              height: 220,
              child: LineChart(
                LineChartData(
                  minX: 0,
                  maxX: length.toDouble().clamp(50, maxPoints.toDouble()),
                  minY: (minY - 1).clamp(0, double.infinity),
                  maxY: maxY + 1,
                  gridData: FlGridData(show: true),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: true, reservedSize: 40),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: true, reservedSize: 24),
                    ),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    for (final (name, data, color) in series)
                      LineChartBarData(
                        isCurved: true,
                        color: color,
                        barWidth: 2,
                        dotData: FlDotData(show: false),
                        spots: [
                          for (int i = 0; i < data.length; i++)
                            FlSpot(i.toDouble(), data[i]),
                        ],
                      ),
                  ],
                  // legendData: const LegendData(show: false),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: theme.dividerColor),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 12,
              runSpacing: 8,
              children: [
                for (final (name, _, color) in series)
                  _LegendChip(name: name, color: color),
              ],
            ),
          ],
        ),
      ),
    );
  }

  double _maxY(List<SeriesDef> s) {
    double m = 0;
    for (final (_, data, _) in s) {
      for (final v in data) {
        if (v > m) m = v;
      }
    }
    return m == 0 ? 1 : m;
  }

  double _minY(List<SeriesDef> s) {
    double m = double.infinity;
    for (final (_, data, _) in s) {
      for (final v in data) {
        if (v < m) m = v;
      }
    }
    return m == double.infinity ? 0 : m;
  }
}

class _LegendChip extends StatelessWidget {
  final String name;
  final Color color;

  const _LegendChip({required this.name, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 12, height: 12, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 6),
        Text(name),
      ],
    );
  }
}
