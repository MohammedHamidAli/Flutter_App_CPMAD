import 'dart:async';
import 'package:sensors_plus/sensors_plus.dart';

/// Streams accelerometer readings and offers simple utilities.
class SensorService {
  StreamSubscription<AccelerometerEvent>? _accelSub;

  void start(void Function(AccelerometerEvent event) onData) {
    _accelSub = accelerometerEvents.listen(onData, onError: (e) {
      // Optionally log error
    }, cancelOnError: false);
  }

  Future<void> stop() async {
    await _accelSub?.cancel();
    _accelSub = null;
  }

  bool get isRunning => _accelSub != null;
}
