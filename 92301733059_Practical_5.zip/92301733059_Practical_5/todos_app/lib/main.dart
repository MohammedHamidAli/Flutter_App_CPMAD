import 'package:flutter/material.dart';

// The main entry point for the Flutter application.
void main() {
  runApp(const TodoApp());
}

// The root widget of the application.
class TodoApp extends StatelessWidget {
  const TodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo App',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const TodoListScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// A simple data model class to represent a Todo item.
class Todo {
  final String id;
  final String title;
  bool isCompleted;

  Todo({required this.id, required this.title, this.isCompleted = false});
}

// The main screen of the app, which is a StatefulWidget to manage the state.
class TodoListScreen extends StatefulWidget {
  const TodoListScreen({super.key});

  @override
  State<TodoListScreen> createState() => _TodoListScreenState();
}

// The State class for TodoListScreen, containing the app's logic and UI.
class _TodoListScreenState extends State<TodoListScreen> {
  // A list to hold all the todo objects.
  final List<Todo> _todos = [];
  // Controller for the text input field in the dialog.
  final TextEditingController _textFieldController = TextEditingController();

  /// Toggles the completion status of a todo item.
  void _toggleTodoStatus(String id) {
    setState(() {
      final todo = _todos.firstWhere((todo) => todo.id == id);
      todo.isCompleted = !todo.isCompleted;
    });
  }

  /// Deletes a todo item from the list.
  void _deleteTodo(String id) {
    setState(() {
      _todos.removeWhere((todo) => todo.id == id);
    });
  }

  /// Adds a new todo item to the list.
  void _addTodoItem(String title) {
    if (title.isNotEmpty) {
      setState(() {
        _todos.add(Todo(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: title,
        ));
      });
      _textFieldController.clear();
      Navigator.of(context).pop(); // Close the dialog
    }
  }

  /// Displays a dialog for adding a new todo.
  Future<void> _displayAddDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add a new todo item'),
          content: TextField(
            controller: _textFieldController,
            decoration: const InputDecoration(hintText: 'Enter todo title'),
            autofocus: true,
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                _textFieldController.clear();
              },
            ),
            ElevatedButton(
              child: const Text('Add'),
              onPressed: () => _addTodoItem(_textFieldController.text),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // Filtered lists for pending and completed todos.
    final List<Todo> _pendingTodos =
        _todos.where((todo) => !todo.isCompleted).toList();
    final List<Todo> _completedTodos =
        _todos.where((todo) => todo.isCompleted).toList();

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Todo List'),
          centerTitle: true,
          bottom: const TabBar(
            tabs: [
              Tab(text: 'All'),
              Tab(text: 'Pending'),
              Tab(text: 'Completed'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildTodoList(_todos, 'No todos yet. Add one!'),
            _buildTodoList(_pendingTodos, 'No pending todos.'),
            _buildTodoList(_completedTodos, 'No completed todos.'),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: _displayAddDialog,
          tooltip: 'Add Todo',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  /// Builds a list view widget for a given list of todos.
  Widget _buildTodoList(List<Todo> todos, String emptyListMessage) {
    if (todos.isEmpty) {
      return Center(
        child: Text(
          emptyListMessage,
          style: const TextStyle(fontSize: 18, color: Colors.grey),
        ),
      );
    }
    return ListView.builder(
      itemCount: todos.length,
      itemBuilder: (context, index) {
        final todo = todos[index];
        return Card(
          elevation: 2,
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: ListTile(
            leading: Checkbox(
              value: todo.isCompleted,
              onChanged: (bool? value) {
                _toggleTodoStatus(todo.id);
              },
            ),
            title: Text(
              todo.title,
              style: TextStyle(
                decoration: todo.isCompleted
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
                color: todo.isCompleted ? Colors.grey : Colors.black,
              ),
            ),
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteTodo(todo.id),
            ),
          ),
        );
      },
    );
  }

  // Dispose the controller when the widget is removed from the widget tree.
  @override
  void dispose() {
    _textFieldController.dispose();
    super.dispose();
  }
}
